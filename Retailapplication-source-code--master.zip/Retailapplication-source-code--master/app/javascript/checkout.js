class checkoutDataTable {

  updateSoldItems() {
    $.ajax({
      type:'patch',
      url:'/update_sold_items',
      data: { authenticity_token: $('[name="csrf-token"]')[0].content },
      success: function(result) {
        if (result.message) {
          toastr.success(result.message);
          setTimeout(function() {
            window.location.reload();
          }, 1000);
        }
      },
      failure: function(e) {
        console.log(e);
      }
    });
  }

  clearCheckoutItems() {
    var status = confirm("Are you sure, you want to clear checkout table?");
    if(status){
      $.ajax({
        type:'put',
        url:'/clear_checkout_items',
        data: { authenticity_token: $('[name="csrf-token"]')[0].content },
        success: function(result) {
          if (result.message) {
            toastr.success(result.message);
            setTimeout(function() {
              window.location.reload();
            }, 1000);
          }
        },
        failure: function(e) {
          console.log(e);
        }
      });
    } else {
      return false;
    }
  }
}

$(function() {
  var checkout_data = new checkoutDataTable();

  var checkout_table = loadDatatable();

  function loadDatatable() {
    var table = $('#checkout_data').DataTable({
      pagingType: 'full_numbers',
      lengthChange: false,
      scrollX: true,
      retrieve: true,
      ajax: {
        url: '/get_checkout_items',
        type: 'GET',
        data: {}
      },
      columns: [
        { "data": "id" },
        { "data": "plant" },
        { "data": "plant2" },
        { "data": "plant3" },
        { "data": "retek_class" },
        { "data": "retek_subclass" },
        { "data": "season" },
        { "data": "ean_number" },
        { "data": "rfid_number" },
        { "data": "variant_size" },
        { "data": "style_code" },
        { "data": "st_loc" },
        { "data": "variant" },
        { "data": "mrp" },
        { "data": "soh_blocked_stock" },
        { "data": "soh_without_blocked_stock" },
        { "data": "soh_quantity" },
        { "data": "soh_value" }
      ],
      "columnDefs": [
        {
            "render": function (data, type, row, meta) {
              return meta.row + meta.settings._iDisplayStart + 1;
            },
            "targets": 0
        }
      ]
    });
    return table;
  }

  $("#cancelCheckout").on("click", function() {
    checkout_data.clearCheckoutItems()
  });

  $('#proceedToPay').on('click', function() {
    checkout_data.updateSoldItems()
  })
})