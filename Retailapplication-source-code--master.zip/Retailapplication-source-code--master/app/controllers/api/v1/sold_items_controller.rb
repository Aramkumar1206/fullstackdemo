class Api::V1::SoldItemsController < ApplicationController
  skip_before_action :verify_authenticity_token
  protect_from_forgery with: :null_session

  #
  # update_sold_items
  # It will add stock items to checkout page if RFID Number matched
  #
  def update_sold_items
    errors = []
    tag_reads = params[:_json] if params[:_json].present?
    tag_reads.present? && tag_reads.each do | tag_read |
      stock_item = StockItem.find_by(rfid_number: tag_read[:data][:idHex].upcase)
      if stock_item.present?
        stock_item.update!(checkout: true) if (stock_item.status != "sold")
      else
        errors << tag_read[:data][:idHex]
      end
    end
    if errors.present?
      response_failure('Stock is not present with these RFID numbers ' + errors.uniq.to_sentence, 409)
    else
      response_success('Stock items added to checkout page', 200)
    end
  rescue Exception => e
    response_failure(e, 500)
  end

  #
  # update_stock_items
  # It will update stock items as scanned/stock via RFID BOT if RFID Number matched
  #
  def update_stock_items
    errors = []
    tag_reads = params[:_json] if params[:_json].present?
    tag_reads.present? && tag_reads.each do | tag_read |
      stock_item = StockItem.find_by(rfid_number: tag_read[:data][:idHex].upcase)
      if stock_item.present?
        stock_item.update!(status: 1, rfid_bot: true) if (stock_item.status != "sold")
      else
        errors << tag_read[:data][:idHex]
      end
    end
    if errors.present?
      response_failure('Stock is not present with these RFID numbers ' + errors.uniq.to_sentence, 409)
    else
      response_success('Stock items updated successfully', 200)
    end
  rescue Exception => e
    response_failure(e, 500)
  end
end