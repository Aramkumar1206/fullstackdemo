class Api::V1::DataSheetsController < ApplicationController
  skip_before_action :verify_authenticity_token
  before_action :require_login_signature

  #
  # get_daily_sheet_details
  # To get daily sheet details imported by admin
  #
  def get_daily_sheet_details
    if DataSheet.active.last.present?
      response_success('Daily sheet details ready!', 200, ActiveModelSerializers::SerializableResource.new(DataSheet.active.last, serializer: DataSheetSerializer))
    else
      response_failure('Daily data sheet not uploaded by super admin!', 409)
    end
  rescue Exception => e
    response_failure(e, 500)
  end

  #
  # get_daily_stock_items
  # To get daily stock items imported by admin
  #
  def get_daily_stock_items
    stock_items = DataSheet.active.last.present? ? DataSheet.active.last.stock_items.active.with_rfid : []
    response_success('Daily stock items data ready!', 200, ActiveModelSerializers::SerializableResource.new(stock_items, each_serializer: StockItemSerializer))
  rescue Exception => e
    response_failure(e, 500)
  end

  #
  # get_report_data
  # To get and return report data
  #
  def get_report_data
    response_success('Report data ready!', 200, ActiveModelSerializers::SerializableResource.new(DataSheet.active.last, serializer: ReportSerializer))
  rescue Exception => e
    response_failure(e, 500)
  end

  #
  # update_stock_status
  # To update stock item status as scanned or missed
  #
  def update_stock_status
    tag_reads = params[:tag_reads]
    tag_reads.present? && tag_reads.each do | tag_read |
      stock_item = StockItem.find_by(rfid_number: tag_read[:epc])
      stock_item.update(status: tag_read[:status]) if stock_item.present?
    end
    response_success('Stock item status updated!', 200)
  rescue Exception => e
    response_failure(e, 500)
  end
end