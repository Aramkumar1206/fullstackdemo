class ErrorsController < ApplicationController
  layout 'error'

end