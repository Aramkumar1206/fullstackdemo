class CheckoutController < ApplicationController
  skip_before_action :verify_authenticity_token, only: [:update_sold_items, :clear_checkout_items]
  before_action :authenticate_user!

  def index
  end

  def get_checkout_items
    if DataSheet.last.present?
      checkout_items = DataSheet.checkout_items
    else
      checkout_items = []
    end
    response_success("Data ready", 200, checkout_items)
  end

  def update_sold_items
    checkout_items = DataSheet.checkout_items if DataSheet.last.present?
    checkout_items.present? && checkout_items.each do | stock_item |
      stock_item.update!(status: 2)
    end
    response_success("Payment done successfully.", 200)
  rescue Exception => e
    response_failure(e, 500)
  end

  def clear_checkout_items
    checkout_items = DataSheet.checkout_items if DataSheet.last.present?
    checkout_items.present? && checkout_items.each do | stock_item |
      stock_item.update!(checkout: false)
    end
    response_success("Removed all the checkout items", 200)
  rescue Exception => e
    response_failure(e, 500)
  end
end