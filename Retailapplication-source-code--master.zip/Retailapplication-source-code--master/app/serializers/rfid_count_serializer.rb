class RfidCountSerializer < ActiveModel::Serializer
  attributes :total, :with_rfid, :without_rfid

  def total
    object.stock_items.active.count
  end

  def with_rfid
    object.stock_items.active.with_rfid.count
  end

  def without_rfid
    object.stock_items.active.without_rfid.count
  end
end