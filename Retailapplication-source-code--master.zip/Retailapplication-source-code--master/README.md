# README

Required softwares:
-------------------
ruby version 3.1.0

rails version 7.0.5.1


Go to project folder in the console/terminal:
--------------------------------------------
example: 
C:/project_name>


Open files in a code editor:
----------------------------
Under project root folder rename '.env.example' file as '.env'

Under config folder rename 'database.yml.example' file as 'database.yml'


Run these commands in local:
----------------------------
bundle install

rake db:create

rake db:migrate

rake db:seed load_only=000_roles.rb

rake db:seed load_only=001_admin_users.rb

rake assets:precompile


To start the rails server with port 3002:
----------------------------------------
rails s -p 3002


Open browser tab and try below link:
------------------------------------
http://localhost:3002



Admin credentials after running above commands:
----------------------------------------------
Email ID: admin@rim.com

Password: Password@123

