import { StyleSheet, Text, View, Image } from 'react-native'
import React from 'react'
import { horizontalScale, verticalScale } from '../Theme'
import {Images, Colors, CommonStyles} from '../Theme'

const ReportInfo = ({title, icon, count, backgroundColor}) => {
  return (
    <View style = {[styles.container, {backgroundColor}]}>

      <View style = {styles.content}>

        {/* ICON WITH TITLE */}
        <View style = {{flexDirection : "row", alignItems : "center"}}>
            {/* <Image source = {icon} style = {styles.icon}/> */}
            {icon}
            <Text style = {styles.reportTitle}>{title}</Text>
        </View>

        {/* COUNT */}
        <View style = {styles.countTextContainer}>
            <Text style = {styles.countText}>{count}</Text>

        </View>
        
      </View>
    </View>
  )
}

export default ReportInfo

const styles = StyleSheet.create({
    container : {
        height : verticalScale(65),
        borderRadius : verticalScale(5),
        marginBottom : verticalScale(15),
        flexDirection : "row",
        justifyContent : "center"
    },
    content : {
        flex : 0.9,
        flexDirection : "row",
        alignItems : "center",
        justifyContent : "space-between"
        
    },
    icon : {
        width : horizontalScale(45),
        height : verticalScale(45),
        resizeMode : "contain"
    },
    reportTitle : {
        fontSize : horizontalScale(20),
        color : Colors.TextPrimary,
        marginLeft : horizontalScale(10),
  fontFamily:'Montserrat-SemiBold'
    },
    countTextContainer : {
        backgroundColor : "white",
        height : "70%",
        justifyContent : "center",
        paddingHorizontal : horizontalScale(20),
        borderRadius : verticalScale(5)
        // paddingVertical : verticalScale(5)
        
    },
    countText : {
        fontSize : horizontalScale(30),
        color : Colors.TextPrimary,
        fontFamily:'Montserrat-Medium'
        
    }
})