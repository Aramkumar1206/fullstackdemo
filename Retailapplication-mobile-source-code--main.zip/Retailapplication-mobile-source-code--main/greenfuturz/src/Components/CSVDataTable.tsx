// import React, {useEffect} from 'react';
// import {
//   StyleSheet,
//   ScrollView,
//   View,
//   ActivityIndicator,
//   Text,
// } from 'react-native';
// import csv from 'csvtojson';
// import {DataTable} from 'react-native-paper';
// import AsyncStorage from '@react-native-async-storage/async-storage';

// type Props = {
//   numItemsPerPage: number;
//   csvFileUrl: string;
//   saveCSVDataLocal: (csvRow: Array<any>) => {};
// };
// export default function DisplayCsvDataTable({
//   numItemsPerPage,
//   csvFileUrl,
//   saveCSVDataLocal,
// }: Props) {
//   const [page, setPage] = React.useState(0);
//   const [numberOfItemsPerPage, setNumberOfItemsPerPage] = React.useState(10);
//   const [loading, setLoading] = React.useState(true);

//   const [state, setState] = React.useState({
//     tableHead: [],
//     tableData: [[]],
//     currentPageData: [[]],
//     numberOfPages: 1,
//   });

//   useEffect(() => {
//     setTableData();
//     setNumberOfItemsPerPage(numItemsPerPage);
//   }, []);

//   useEffect(() => {
//     setCurrentPageData();
//   }, [page]);

//   useEffect(() => {
//     setCurrentPageData();
//   }, [state.tableData]);

//   const setCurrentPageData = () => {
//     const startIndex = page * numberOfItemsPerPage;
//     let endIndex = startIndex + numberOfItemsPerPage;
//     if (endIndex > state.tableData.length) {
//       endIndex = state.tableData.length;
//     }
//     if (state.tableData.length > 1) {
//       setState({
//         ...state,
//         currentPageData: state.tableData.slice(startIndex, endIndex),
//       });
//     }
//   };

//   const updateDataTable = csvRow => {
//     saveCSVDataLocal(csvRow);
//     let pages = ~~(csvRow.length / numberOfItemsPerPage);
//     let additional = csvRow.length % numberOfItemsPerPage;

//     if (additional > 1) {
//       pages = pages + 1;
//     }
//     setState({
//       ...state,
//       tableHead: csvRow[0],
//       tableData: csvRow.slice(1),
//       numberOfPages: pages,
//     });
//     setLoading(false);
//   };

//   const fetchCSVData = () => {
//     fetch(csvFileUrl)
//       .then(async response => {
//         const resp = await response.text();
//         csv({
//           noheader: true,
//           output: 'csv',
//         })
//           .fromString(resp)
//           .then(csvRow => {
//             updateDataTable(csvRow);
//           });
//       })
//       .catch(error => {
//         console.error('some error occurred', error);
//       })
//       .finally(() => {
//         setLoading(false);
//       });
//   };

//   const setTableData = () => {
//     AsyncStorage.getItem('perDaySheet').then((data: string) => {
//       if (data) {
//         let parsedData = JSON.parse(data);
//         if (parsedData.date == '12/07/2023') {
//           console.log('already saved');
//           updateDataTable(parsedData.csvData);
//         } else {
//           console.log('re saved');
//           fetchCSVData();
//         }
//       } else {
//         console.log('new save');
//         fetchCSVData();
//       }
//     });
//   };

//   return (
//     <>
//       {loading ? (
//         <View style={styles.loadingView}>
//           <ActivityIndicator size="large" color={'#000'} />
//           <Text style={{marginTop: 20}}>Importing the sheet...!</Text>
//         </View>
//       ) : (
//         <ScrollView style={styles.container}>
//           <DataTable style={{}}>
//             <ScrollView
//               horizontal
//               contentContainerStyle={{flexDirection: 'column'}}>
//               <DataTable.Header style={{backgroundColor: '#0C54A0'}}>
//                 {state.tableHead.map((rowData, index) => (
//                   <DataTable.Title
//                     style={[styles.titleStyle,{borderRightWidth:
//                       state.tableHead.length - 1 == index ? 0 : 1,}]}
//                     textStyle={styles.titleTextStyle}
//                     key={index}>
//                     {rowData}
//                   </DataTable.Title>
//                 ))}
//               </DataTable.Header>

//               {state.currentPageData.map((rowData, index) => (
//                 <DataTable.Row
//                   style={styles.rowStyle}
//                   key={index}>
//                   {rowData.map((cellData, cellIndex) => (
//                     <DataTable.Cell
//                       style={[styles.cellStyle,{borderRightWidth:
//                         rowData.length - 1 == cellIndex ? 0 : 1,}]}
//                       textStyle={{color: '#000', fontSize: 13}}
//                       numberOfLines={2}
//                       key={cellIndex}>
//                       {cellData}
//                     </DataTable.Cell>
//                   ))}
//                 </DataTable.Row>
//               ))}
//             </ScrollView>
//             <DataTable.Pagination
//               page={page}
//               numberOfPages={state.numberOfPages}
//               onPageChange={page => setPage(page)}
//               label={`Page ${page + 1} of ${state.numberOfPages}`}
//               showFastPagination
//               optionsLabel={'Rows per page'}
//             />
//           </DataTable>
//         </ScrollView>
//       )}
//     </>
//   );
// }
// const styles = StyleSheet.create({
//   container: {flex: 1, margin: 20, backgroundColor: '#fff'},
//   head: {
//     height: 40,
//     backgroundColor: '#f1f8ff',
//     color: '#fff',
//   },
//   text: {margin: 6},
//   loadingView: {
//     flex: 1,
//     alignItems: 'center',
//     justifyContent: 'center',
//     alignContent: 'center',
//     marginTop: 100,
//   },
//   rowStyle:{
//     flex: 1,
//     width: '100%',
//     height: 50,
//     borderBottomWidth: 1, 
//     borderBottomColor: 'gray',
//   },
//   cellStyle:{
//     width: 110,
//     paddingLeft: 10,
    
//     borderColor: 'gray',
//   },
//   titleStyle:{
//   width: 110,
//   paddingLeft: 10,
  
//   borderColor: '#fff',
// },
// titleTextStyle:{
//   color: '#fff',
//   fontWeight: 'bold',
//   fontSize: 13,
// }

// });
