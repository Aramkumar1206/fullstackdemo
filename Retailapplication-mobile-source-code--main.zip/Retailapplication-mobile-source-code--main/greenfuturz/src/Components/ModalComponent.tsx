import {StyleSheet, Modal, View, Text, TouchableOpacity} from 'react-native';
import React from 'react';
import Ionicons from 'react-native-vector-icons/Ionicons';

const ModalComponent = ({modalVisible, setModalVisible, errorText}) => {
  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={modalVisible}
      onRequestClose={() => {
        setModalVisible(!modalVisible);
      }}>
      <View style={styles.centeredView}>
        <View style={styles.modalView}>
          <Ionicons
            style={{alignSelf: 'center', marginTop: 20}}
            name={'warning-outline'}
            size={40}
            color={'red'}
          />

          <Text style={styles.modalText}>{errorText}</Text>
          <TouchableOpacity
            style={styles.scanButtonStyle}
            onPress={() => {
              setModalVisible(!modalVisible);
            }}>
            <Text style={{color: '#fff', fontFamily: 'Montserrat-SemiBold'}}>
              Close
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
};

export default ModalComponent;

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalView: {
    width: '80%',
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 20,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },

  modalText: {
    marginBottom: 15,
    textAlign: 'center',
    alignSelf: 'center',
    marginTop: 20,
    color: '#000',
    fontFamily: 'Montserrat-SemiBold',
  },
  scanButtonStyle: {
    marginTop: 20,
    alignSelf: 'center',
    width: '50%',
    backgroundColor: '#0C54A0',
    borderRadius: 5,
    padding: 10,
    alignItems: 'center',
  },
});
