import React, {useEffect, useState} from 'react';
import {
  StyleSheet,
  ScrollView,
  View,
  ActivityIndicator,
  Text,
  TextInput,
  Platform,
  // RefreshControl
} from 'react-native';
import {DataTable} from 'react-native-paper';

type Props = {
  numItemsPerPage: number;
  csvData: Array<any>;
  isReport: boolean;
};
export default function ReportTable({
  numItemsPerPage,
  csvData,
  isReport,
}: Props) {
  const [page, setPage] = useState(0);
  const [numberOfItemsPerPage, setNumberOfItemsPerPage] = useState(10);
  const [loading, setLoading] = useState(true);
  const [keys, setkeys] = useState([]);
  const [search, setSearch] = useState('');

  const [state, setState] = useState({
    tableHead: [],
    tableData: [],
    currentPageData: [],
    numberOfPages: 1,
  });

  useEffect(() => {
    updateTable()
  }, [search,csvData]);

  const updateTable = async () =>{
    setLoading(true);
    if (csvData.length > 0) {
    let data = csvData;
    if (search) {
      data = data.filter(o => {
        if (
          o['ean_number']?.toLowerCase().indexOf(search.toLowerCase()) >= 0 ||
          o['rfid_number']?.toLowerCase().indexOf(search.toLowerCase()) >= 0
        )
          return true;
      });
    }

    var sortedData = data.slice(0);
    sortedData.sort(function (a, b) {
      var x = a.id;
      var y = b.id;
      return x < y ? -1 : x > y ? 1 : 0;
    });
      updateDataTable(sortedData);
      setPage(0);
    } else {
      setLoading(false);
    }
    setNumberOfItemsPerPage(numItemsPerPage);
  }

  useEffect(() => {
    setCurrentPageData();
  }, [page]);

  useEffect(() => {
    setCurrentPageData();
  }, [state.tableData]);

  const setCurrentPageData = () => {
    const startIndex = page * numberOfItemsPerPage;
    let endIndex = startIndex + numberOfItemsPerPage;
    if (endIndex > state.tableData.length) {
      endIndex = state.tableData.length;
    }
    if (state.tableData.length > 0) {
      setState({
        ...state,
        currentPageData: state.tableData.slice(startIndex, endIndex),
      });
    }
  };

  const updateDataTable = csvRow => {
    let pages = Math.ceil(csvRow.length / numberOfItemsPerPage )
    // let additional = csvRow.length % numberOfItemsPerPage;
    // if (additional >= 1) {
    //   pages = pages + 1;
    // }
    // if (pages == 0) {
    //   pages = 1;
    // }
    // pages = pages + 1;
    let keys = csvRow.length > 0 ? Object.keys(csvRow[0]) : [];
    setkeys(keys);

    if (csvRow.length == 0) {
      setState({
        ...state,
        tableHead: keys,
        tableData: csvRow,
        numberOfPages: pages,
        currentPageData: [],
      });
    } else {
      setState({
        ...state,
        tableHead: keys,
        tableData: csvRow,
        numberOfPages: pages,
      });
    }
    setLoading(false);
  };

  return (
    <>
      {loading ? (
        <View style={styles.loadingView}>
          <ActivityIndicator size="large" color={'#000'} />
          <Text
            style={{
              marginTop: 20,
              fontSize: 16,
              fontFamily: 'Montserrat-SemiBold',
            }}>
            {isReport
              ? 'Fetching the Generated Report...!'
              : 'Importing the sheet...!'}
          </Text>
        </View>
      ) : (
        <ScrollView style={styles.container}
        >
          <View style={styles.passwordContainer}>
            <TextInput
              style={styles.inputStyle}
              onChangeText={search => {
                setSearch(search);
              }}
              underlineColorAndroid="rgba(0,0,0,0)"
              placeholder="Search EAN or RFID No"
              placeholderTextColor="gray"
              value={search}
            />
          </View>
          
          <DataTable style={{}}>
            <ScrollView
              horizontal
              contentContainerStyle={{flexDirection: 'column'}}>
              <DataTable.Header style={{backgroundColor: '#0C54A0'}}>
                {state.tableHead.map((rowData, index) => {
                  if (
                    rowData == 'data_sheet_id' ||
                    rowData == 'updated_at' ||
                    rowData == 'created_at'
                  ) {
                    return null;
                  } else {
                    return (
                      <DataTable.Title
                        style={[
                          styles.titleStyle,
                          {
                            borderRightWidth:
                              state.tableHead.length - 1 == index ? 0 : 1,
                          },
                        ]}
                        textStyle={styles.titleTextStyle}
                        key={index}>
                        {rowData}
                      </DataTable.Title>
                    );
                  }
                })}
              </DataTable.Header>

              {state.currentPageData.map((rowData, index) => (
                <DataTable.Row
                  style={[
                    styles.rowStyle,
                    {
                      borderBottomWidth: isReport ? 10 : 1,
                      borderBottomColor: isReport ? '#fff' : 'gray',

                      backgroundColor: isReport
                        ? rowData['status'] == 'scanned'
                          ? '#EEFCF2'
                          : '#FCE3E3'
                        : '#fff',
                    },
                  ]}
                  key={index}>
                  {keys.map((key, cellIndex) => {
                    if (
                      key == 'data_sheet_id' ||
                      key == 'updated_at' ||
                      key == 'created_at'
                    ) {
                      return null;
                    } else {
                      return (
                        <View
                          style={[
                            // styles.container,
                            styles.cellStyle,
                            {
                              borderRightWidth:
                                keys.length - 1 == cellIndex ? 0 : 1,
                              backgroundColor: isReport
                                ? rowData['status'] == 'scanned'
                                  ? '#EEFCF2'
                                  : '#FCE3E3'
                                : '#fff',
                              justifyContent: 'center',
                            },
                          ]}
                          // numberOfLines={2}
                          key={cellIndex}>
                          <Text
                            style={{
                              color: '#000',
                              fontSize: 12,
                              fontFamily: 'Montserrat-Medium',
                            }}
                            numberOfLines={2}>
                            {rowData[key]}
                          </Text>
                        </View>
                      );
                    }
                  })}
                </DataTable.Row>
              ))}
            </ScrollView>
            <DataTable.Pagination
              page={page}
              numberOfPages={state.numberOfPages}
              onPageChange={page => setPage(page)}
              label={`Page ${page + 1} of ${state.numberOfPages}`}
              showFastPagination
              showFastPaginationControls
              optionsLabel={'Rows per page'}
            />
          </DataTable>
        </ScrollView>
      )}
    </>
  );
}
const styles = StyleSheet.create({
  container: {flex: 1, margin: 20, backgroundColor: '#fff'},
  head: {
    height: 40,
    backgroundColor: '#f1f8ff',
    color: '#fff',
  },
  text: {margin: 6},
  loadingView: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    alignContent: 'center',
    marginTop: 100,
  },
  rowStyle: {
    flex: 1,
    width: '100%',
    height: 50,
  },
  cellStyle: {
    width: 110,
    paddingLeft: 10,

    borderColor: 'gray',
  },
  titleStyle: {
    width: 110,
    paddingLeft: 10,

    borderColor: '#fff',
  },
  titleTextStyle: {
    color: '#fff',
    fontSize: 16,
    fontFamily: 'Montserrat-SemiBold',
  },
  passwordContainer: {
    flexDirection: 'row',
    backgroundColor: '#F1F7FE',
    borderRadius: 5,
    width: '80%',
    paddingHorizontal: 15,
    color: '#991172',
    marginHorizontal: 30,
    alignSelf: 'center',
    alignItems: 'center',
    margin: 20,
    paddingVertical: Platform.OS == 'ios' ? 15 :0,
  },
  inputStyle: {
    flex: 1,
    fontSize: 14,
    fontFamily: 'Montserrat-SemiBold',
  },
});
