
interface ColorObj {
    [index : string] : string
};

interface CommonStyleObj {
    [index : string] : {
        [index : string] : string
    }
};

let Colors : ColorObj = {
    "Primary" : "#25B54E",
    "Secondary" : "#0C54A0",
    "Teritary" : "#EEFCF2",
    "TextPrimary" : "#272727"
}

let CommonStyles : CommonStyleObj = {
    "Center" : {
        justifyContent : "center",
        alignItems : "center"
    }
}

export {Colors, CommonStyles};



