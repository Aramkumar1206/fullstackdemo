import React, {useEffect, useState} from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  SafeAreaView,
  ScrollView,
  TextInput,
  ActivityIndicator,
} from 'react-native';
import styles from './ForgotPasswordStyles';

import LoginIcon1 from '../Assets/Images/loginIcon1.svg';
import LoginIcon2 from '../Assets/Images/loginIcon2.svg';
import Username from '../Assets/Images/username.svg';
import {APIBASEURL} from '../Constants/constants';

const ForgotPasswordScreen = ({navigation, route}) => {
  const [userName, setUsername] = useState('');

  const [loading, setLoading] = useState(false);

  const [invalidUsername, setInvalidUsername] = useState(false);
  const [apiError, setApiError] = useState(false);
  const [apiErrorMessage, setApiErrorMessage] = useState('');

//   const [resetted, setResetted] = useState(false);

  useEffect(() => {
    // Check Already Logged In
  });

  const setAPIErrorMessageText = (txt: string) => {
    setApiError(true);
    setApiErrorMessage(txt);
  };

  const onSubmit = () => {
    if (!userName.trim()) {
      setInvalidUsername(true);
      return;
    } else {
      setInvalidUsername(false);
      setLoading(true);
      fetch(APIBASEURL + '/forgot_password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          user: {
            email: userName,
          },
        }),
      })
        .then(async response => {
          let res = await response.json();
          if (response.status == 200) {
            navigation.replace('ChangePassword',{
                token : res.reset_password_token
            });
          } else {
            setAPIErrorMessageText(
              res?.error ? res?.error : 'Oops Something Went Wrong...!',
            );
          }
        })

        .catch(error => setAPIErrorMessageText('Oops Something Went Wrong...!'))
        .finally(() => {
            // navigation.replace('ChangePassword',{
            //     token : 'fwfwfef'
            // });
          setLoading(false);
        });
    }
  };

  return (
    <SafeAreaView style={styles.mainContainer}>
      <ScrollView
        contentContainerStyle={{alignItems: 'center', marginTop: '20%'}}
        keyboardShouldPersistTaps="handled">
        <View style={{marginTop: 50, alignItems: 'center'}}>
          <LoginIcon2 />
        </View>
        <View style={{marginTop: 50, alignItems: 'center'}}>
          <LoginIcon1 />
        </View>
          
          <>
            {userName ? (
              <Text style={styles.inputHeaderStyle}>User Name</Text>
            ) : (
              <View style={{marginTop: 20}}></View>
            )}
            <View style={styles.passwordContainer}>
              <TextInput
                style={styles.inputStyle}
                onChangeText={username => {
                  setApiError(false);
                  setInvalidUsername(false);
                  setUsername(username);
                }}
                underlineColorAndroid="rgba(0,0,0,0)"
                placeholder="User Name"
                placeholderTextColor="gray"
                value={userName}
              />
              <Username />
            </View>
            {invalidUsername ? (
              <Text style={styles.invalidPasswordStyle}>
                Enter the Username
              </Text>
            ) : null}

            {apiError ? (
              <Text style={styles.apiErrorStyle}>{apiErrorMessage}</Text>
            ) : null}

            <TouchableOpacity
              style={styles.scanButtonStyle}
              onPress={() => {
                onSubmit();
              }}>
              {loading ? (
                <ActivityIndicator color={'#fff'} />
              ) : (
                <Text
                  style={{
                    color: '#fff',
                    fontFamily: 'Montserrat-SemiBold',
                    fontSize: 16,
                  }}>
                  Submit
                </Text>
              )}
            </TouchableOpacity>
          </>
       
        <View style={{margin: '15%'}}></View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default ForgotPasswordScreen;
