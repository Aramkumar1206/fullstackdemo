import React, { useEffect, useState, useContext } from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  SafeAreaView,
  StatusBar,
  ScrollView,
  FlatList,
  DeviceEventEmitter,
  NativeEventEmitter,
  NativeModules,
  Alert,
  Linking,
  ActivityIndicator,
  Platform,
} from 'react-native';
import styles from './HomeScreenStyles';
import RNBluetoothClassic from 'react-native-bluetooth-classic';
import BluetoothStateManager from 'react-native-bluetooth-state-manager';
import { useIsFocused } from '@react-navigation/native';
import Fontisto from 'react-native-vector-icons/Fontisto';
import Entypo from 'react-native-vector-icons/Entypo';
import RFIDGray from '../Assets/Images/rfidGray.svg';
import Logo from '../Assets/Images/logo.svg';
import Scan from '../Assets/Images/scan.svg';
import Reload from '../Assets/Images/reload.svg';
import Connected from '../Assets/Images/connected.svg';
import Sheet from '../Assets/Images/sheet.svg';
import ReaderIcon from '../Assets/Images/readerIcon.svg';
import ReaderIconWithBg from '../Assets/Images/readerIconWithGrayBg.svg';
import { PERMISSIONS, requestMultiple, request } from 'react-native-permissions';
import { Menu, MenuItem } from 'react-native-material-menu';
import AsyncStorage from '@react-native-async-storage/async-storage';
import ModalComponent from '../Components/ModalComponent';
import { APIBASEURL } from '../Constants/constants';
import { Colors } from '../Theme';
import { AppContext } from '../Context/AppContext';


var { RFIDSDKModule } = NativeModules; // Native module initialize in variable for both Android and IOS


const HomeScreen = ({ navigation, route }) => {

  // Global State
  const {appData, setAppData} = useContext(AppContext)


  const [toggle, setToggle] = useState(false);
  const [connected, setConnected] = useState(false);
  const [selectedRFID, setSelectedRFID] = useState(null);
  const [connectedRFID, setConnectedRFID] = useState(null);
  const [deviceList, setDeviceList] = useState([]);

  const [permissionGranted, setPermissionGranted] = useState(false);
  const [isBluetoothOn, setIsBluetoothOn] = useState(false);

  const [showCSVData, setShowCSVData] = useState(true);
  const [showScan, setShowScan] = useState(false);
  const [showScanReport, setShowScanReport] = useState(true);
  const [loading, setLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [modalText, setModalText] = useState('');
  const [isPressedLogout, setPressedLogout] = useState(false);
  const [menuVisible, setMenuVisible] = useState(false);
  const [configuringReader, setConfiguringReader] = useState(false);

  // Screen Focus Status
  // const isFocused = useIsFocused();
  const platform = Platform.OS;



  useEffect(() => {
    let IOSevent = Platform.OS == "ios" && new NativeEventEmitter(RFIDSDKModule); // For IOS
    let onSessionConnectSubscriber = (IOSevent ? IOSevent : DeviceEventEmitter).addListener(
      'onSessionConnect',
      onSessionConnect,
    );
    let onGetDeviceListSubscriber = DeviceEventEmitter.addListener(
      'onGetDeviceList',
      onGetDeviceList,
    );
    let onSessionDisconnectSubscriber = DeviceEventEmitter.addListener(
      'onSessionDisconnect',
      onSessionDisconnect,
    );

   


    async function getPermission() {
      if (Platform.OS == 'ios') {
 

        let result = await request(
          PERMISSIONS.IOS.BLUETOOTH_PERIPHERAL
        );

        // bluetoothState();
        if (
          result != 'blocked'
        ) {
          setPermissionGranted(true);
        } else {
          setTimeout(()=> {
            setModalVisible(true);
            setModalText('Bluetooth Permission is required');
          }, 500)
         
          setPermissionGranted(false);
        }
      } else {
        if (Platform.Version >= 31) {
          let result = await requestMultiple([
            PERMISSIONS.ANDROID.BLUETOOTH_CONNECT,
            PERMISSIONS.ANDROID.BLUETOOTH_SCAN,
            PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION,
          ]);
          if (
            result['android.permission.BLUETOOTH_CONNECT'] == 'granted' &&
            result['android.permission.BLUETOOTH_SCAN'] == 'granted' &&
            result['android.permission.ACCESS_FINE_LOCATION'] == 'granted'
          ) {
            setPermissionGranted(true);
          } else {
            setModalVisible(true);
            setModalText('Bluetooth Permission is required');
            setPermissionGranted(false);
          }
        } else if (Platform.Version >= 29) {
          let result = await request(PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION);
          if (result == 'granted') {
            setPermissionGranted(true);
          } else {
            setModalVisible(true);
            setModalText('Bluetooth Permission is required');
            setPermissionGranted(false);
          }
        } else {
          let result = await request(PERMISSIONS.ANDROID.ACCESS_COARSE_LOCATION);
          if (result == 'granted') {
            setPermissionGranted(true);
          } else {
            setModalVisible(true);
            setModalText('Bluetooth Permission is required');
            setPermissionGranted(false);
          }
        }
      }
    }
    getPermission();
    if (Platform.OS == 'android') {
      RFIDSDKModule.init();
    } else { // For IOS SDK
      RFIDSDKModule.initializeReaderSdk();

    }



    return () => {
      if (Platform.OS == 'android') {
        RFIDSDKModule.dispose();
      }
      onSessionConnectSubscriber.remove();
      onGetDeviceListSubscriber.remove();
      onSessionDisconnectSubscriber.remove();
    };
  }, []);

 
  

  useEffect(() => {
    let listerner;
    if (permissionGranted) {
      
      listerner =  BluetoothStateManager.onStateChange((bluetoothState) => {
        // console.log(bluetoothState)
          if (bluetoothState == "PoweredOn") {
            setIsBluetoothOn(true);
          } else {
            setIsBluetoothOn(false);
            setTimeout(()=> {
              setModalVisible(true);
            setModalText('Please Turn ON the Bluetooth');

            }, 500)
            
          }
          // do something...
        }, true /*=emitCurrentState*/);

        // listerner = RNBluetoothClassic.onStateChanged(state => {
        //   console.log(state, "Bluetooth listener")
        //   if (state.enabled) {
        //     setIsBluetoothOn(true);
        //   } else {
            
        //   }
        // });

    }

    return () => {
      listerner && listerner.remove();
    };
  }, [permissionGranted]);



  // will be invoked Once connected

  const onSessionConnect = isReaderConnectedId => {
    // console.log("session connect method ", isReaderConnectedId);
    setLoading(false);
    if (isReaderConnectedId) {
      setConnected(true);
      setConnectedRFID(isReaderConnectedId);
      setShowScan(true);
      // console.log("Reader connected")
    } else {
      setModalVisible(true);
      setModalText('Connection Failed');
    }
  };

  // will be invoked Once get the device list
  const onGetDeviceList = (deviceList: Array<any>) => {
    setDeviceList(deviceList);
  };

  // will be invoked Once disconnected
  const onSessionDisconnect = Disconnected => {
    setToggle(false);
    setConnected(false);
    setConnectedRFID(null);
    setShowScan(false);
    setModalVisible(true);
    setModalText('Device Disconnected');



  };

  // function bluetoothState() {
  //   BluetoothStateManager.getState().then((bluetoothState) => {
  //     console.log("Bluetooth State")
  //    console.log(bluetoothState);
  //   });
  // }

  // Will call the native modules to get the device list
  const getAvailableDevices = () => {
    if (Platform.OS == 'android') {
      RFIDSDKModule.getAvailableDevices();
    } else { // For IOS
      getReaderDevices()
    }
    // onGetDeviceList(['wfeff'])
  };

  // Will call the native modules to connect with the device for both Android and IOS
  const connectRFIDReader = async (readerName: string) => {
    setLoading(true);
    RFIDSDKModule.connectRFIDReader(readerName);

  };

  // Will call the native modules to disconnect  the device
  const disconnect = async () => {

    let disconnectStatus = await RFIDSDKModule.disconnectRFIDReader();
    // console.log(disconnectStatus, "Disconnection status");

    if (disconnectStatus == 'Disconnected') {
      setConnected(false);
      setConnectedRFID(null);
      setShowScan(false);
    } else {
      setConnected(false);
      setConnectedRFID(null);
      setShowScan(false);
      setModalVisible(true);
      setModalText('Operation Failed');
    }
    return disconnectStatus;
  };


  async function readTagEvent() {
    if (connected && toggle && !configuringReader) {
      try {
        setConfiguringReader(true)
        // if(Platform.OS == 'android'){
        await RFIDSDKModule.readTagEvents('Listen');
        navigation.navigate('ScanScreen', {
          connectedRFID: connectedRFID,
        });
        // }

      } catch (error) {
        // if (error == "Error") {
        setModalVisible(true);
        setModalText('Operation Failed');
        // }
      } finally {
        setConfiguringReader(false)
      }

    }


  }

  const showConsentPopup = () => {
    Alert.alert(
      'Alert',
      'Please Enable Bluetooth Permissions',
      [
        { text: 'Go To Settings', onPress: () => Linking.openSettings() },
        { text: 'Cancel', onPress: () => console.log('OK button clicked') },
      ],
      {
        cancelable: true,
      },
    );
  };

  const onPressToggle = () => {
    // RFIDSDKModule.triggerEvent();
    // RFIDSDKModule.initializeReaderSdk();
    if (!permissionGranted) {
      showConsentPopup();
      return;
    }
    if (toggle) {
      setLoading(false);
      if (connected) {
        disconnect();
      } else {
        setConnected(false);
        setConnectedRFID(null);
        setShowScan(false);
      }
    } else {
      getAvailableDevices();
    }
    setToggle(!toggle);
  };

  const onLogout = async () => {
    setPressedLogout(true);
    let disConnectionStatus = connected && (await disconnect());
    if (disConnectionStatus == 'Disconnected' || !connected) {

      fetch(`${appData.apiURL}/logout?Authentication+key=RFD40+greenfuturzapi@`,{
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          ...(appData.apiKey && {Authorization: appData.apiKey}),
        }
      }
  )
        .then(async response => {
          let res = await response.json();
          if (response.status == 200) {
           await AsyncStorage.removeItem('access-key');
            setAppData({
              ...appData, apiKey : ""
            })
            navigation.replace('LoginScreen');
          } else {
            setModalVisible(true);
            setModalText(res?.error ? res?.error : 'Logout Failed');
          }
        })

        .catch(error => {
          setModalVisible(true);
          setModalText('Logout Failed');
        })
        .finally(() => {
          setPressedLogout(false);
        });
    } else {
      setPressedLogout(false);
    }
  };

  async function getReaderDevices() {

    try {
      let devicesData = await RFIDSDKModule.getAvailableDevices();
      let readerDevices = Object.keys(devicesData);
      onGetDeviceList(readerDevices);
      // console.log(readerDevices)


    } catch (error) {
      // console.log(error)
    }

  }

  return (
    <SafeAreaView style={styles.mainContainer}>
      <StatusBar
        backgroundColor={'#EEFCF2'}
        barStyle={'dark-content'}
        hidden={false}
      />
      <ModalComponent
        modalVisible={modalVisible}
        setModalVisible={param => {
          setModalVisible(param);
        }}
        errorText={modalText}
      />

      <View style={styles.topContainer}>
        <View style={styles.topLeftContainer}>
          <Logo />
        </View>
        <View style={styles.plusIconContanier}>
          <TouchableOpacity
            onPress={() => {
              setMenuVisible(!menuVisible);
              // onLogout();
            }}>
            <Menu
              style={styles.menuStyle}
              visible={menuVisible}
              onRequestClose={() => setMenuVisible(false)}>
              <MenuItem
                onPress={() => {
                  navigation.navigate('ChangePassword');
                  setMenuVisible(false);
                }}>
                <View
                  style={[
                    styles.menuItemStyle,

                    {
                      paddingLeft: Platform.OS === 'ios' ? 10 : 0,
                    },
                  ]}>
                  <Text style={styles.menuItemTextStyle} numberOfLines={2}>
                    Reset Password
                  </Text>
                </View>
              </MenuItem>
              <MenuItem
                onPress={() => {
                  onLogout();
                  setMenuVisible(false);
                }}>
                <View
                  style={[
                    styles.menuItemStyle,

                    {
                      paddingLeft: Platform.OS === 'ios' ? 10 : 0,
                    },
                  ]}>
                  <Text style={[styles.menuItemTextStyle]}>Logout</Text>
                  {isPressedLogout ? (
                    <>
                      <ActivityIndicator
                        style={{ marginLeft: 10 }}
                        color={'#000'}
                        size={'small'}
                      />
                    </>
                  ) : null}
                </View>
              </MenuItem>
            </Menu>

            <Entypo name={'user'} size={30} color={'#0C54A0'} />
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.onOffContainer}>
        <View style={styles.onOffLeftContainer}>
          <TouchableOpacity style={{ alignSelf: 'center' }} onPress={() => { }}>
            <ReaderIconWithBg />
          </TouchableOpacity>
          <Text style={styles.connectTextStyles}>Connect Reader</Text>
        </View>
        <View style={styles.toggleContainer}>
          <TouchableOpacity
            style={{ alignSelf: 'center' }}
            onPress={() => {
              onPressToggle();
            }}>
            {toggle ? (
              <Fontisto name={'toggle-on'} size={35} color={'#0C54A0'} />
            ) : (
              <Fontisto name={'toggle-off'} size={35} color={'#E5E4E4'} />
            )}
          </TouchableOpacity>
        </View>
      </View>

      {toggle ? (
        !connected ? (
          <View style={styles.listDeviceContainer}>
            <View style={styles.listDeviceTopContainer}>
              <Text style={[styles.addDeviceTextStyle, {}]}>Add Device</Text>
              <TouchableOpacity
                style={{ alignSelf: 'center' }}
                onPress={() => {
                  getAvailableDevices();
                }}>
                <Reload />
              </TouchableOpacity>
            </View>
            {/* <View style={{}} > */}
            <FlatList
              // scrollEnabled={true}
              // style={{maxHeight:'50%'}}
              contentContainerStyle={{
                flexGrow: 0,
              }}
              data={deviceList}
              renderItem={({ item, index }) => {
                return (
                  <TouchableOpacity
                    style={styles.listStyle}
                    onPress={() => {
                      connectRFIDReader(item);
                      setSelectedRFID(item);
                    }}>
                    <View style={[styles.onOffLeftContainer, { padding: 20 }]}>
                      <TouchableOpacity
                        style={{ alignSelf: 'center' }}
                        onPress={() => { }}>
                        <RFIDGray />
                      </TouchableOpacity>
                      <Text
                        style={[
                          styles.addDeviceTextStyle,
                          {
                            alignSelf: 'center',
                            marginLeft: 15,
                          },
                        ]}>
                        {item}
                        {'\n'}
                        <Text
                          style={{
                            color: 'gray',
                            fontSize: 10,
                            fontFamily: 'Montserrat-Regular',
                          }}>
                          {selectedRFID == item && loading
                            ? 'Connecting...!'
                            : 'Paired'}
                        </Text>
                      </Text>
                    </View>
                    {selectedRFID == item && loading ? (
                      <View style={styles.toggleContainer}>
                        <TouchableOpacity
                          style={{ alignSelf: 'center' }}
                          onPress={() => {
                            // onPressToggle();
                          }}>
                          <ActivityIndicator color={'#000'} />
                        </TouchableOpacity>
                      </View>
                    ) : null}
                  </TouchableOpacity>
                );
              }}
            />
            {/* </View> */}
          </View>
        ) : (
          <View style={styles.connectedDeviceContainer}>
            <View style={styles.onOffLeftContainer}>
              <TouchableOpacity
                style={{ alignSelf: 'center' }}
                onPress={() => { }}>
                <ReaderIcon />
              </TouchableOpacity>
              <View
                style={{
                  flexDirection: 'column',
                  alignSelf: 'center',
                }}>
                <Text style={[styles.addDeviceTextStyle, { marginLeft: 20 }]}>
                  {connectedRFID}
                </Text>
                <Text style={styles.pairTextStyle}>Connected</Text>
              </View>
            </View>
            <View style={styles.toggleContainer}>
              <TouchableOpacity
                style={{ alignSelf: 'center' }}
                onPress={() => { }}>
                <Connected />
              </TouchableOpacity>
            </View>
          </View>
        )
      ) : null}
      <ScrollView style={{ flex: 1 }}>
        {showCSVData ? (
          <View style={styles.dataSheetContainer}>
            <Text style={styles.sheetTextStyle}>Daily Data Sheet</Text>
            <View style={styles.rowContainer}>
              <View style={{ flexDirection: 'row', flex: 1 }}>
                <Sheet />
                <Text style={styles.longTextStyle}>
                  Data imported successfully {'\n'}
                  by the super admin
                </Text>
              </View>
              <TouchableOpacity
                style={styles.viewButton}
                onPress={() => {
                  navigation.navigate('DataSheetScreen');
                  
                }}>
                <Text
                  style={{ color: '#fff', fontFamily: 'Montserrat-SemiBold' }}>
                  View
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        ) : null}

        {showScan ? (
          <View style={styles.scanContainer}>
            <View style={styles.scanView}>
              <Scan />

              <TouchableOpacity
                style={styles.scanButtonStyle}
                onPress={readTagEvent}>
                {configuringReader ? (
                  <ActivityIndicator color={'#fff'} />
                ) : (
                  <Text
                    style={{ color: '#fff', fontFamily: 'Montserrat-SemiBold' }}>
                    Scan
                  </Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        ) : null}
        {showScanReport ? (
          <TouchableOpacity
            style={[
              styles.scanButtonStyle,
              {
                borderColor: '#25B54E',
                borderWidth: 1,
                backgroundColor: '#fff',
                marginBottom: 20,
              },
            ]}
            onPress={() => {
              navigation.navigate('ReportScreen', {
                // scannedIds: tagData,
                // csvData: csvData,
                // compareIndex: compareIndex,
              });
            }}>
            <Text style={{ color: '#25B54E', fontFamily: 'Montserrat-SemiBold' }}>
              View Scanned Report
            </Text>
          </TouchableOpacity>
        ) : null}
      </ScrollView>
      {/* </View> */}
    </SafeAreaView>
  );
};

export default HomeScreen;
