import React, {useEffect, useState, useContext} from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  SafeAreaView,
  ScrollView,
  StatusBar,
  Alert,
  ActivityIndicator,
} from 'react-native';
import ReportTable from '../Components/ReportTable';
import Back from '../Assets/Images/back.svg';
import ReportInfo from '../Components/ReportInfo';
import styles from './ReportScreenStyle';

import Missed from '../Assets/Images/missed.svg';
import Scanned from '../Assets/Images/scanned.svg';
import Total from '../Assets/Images/total.svg';
import {Colors, verticalScale} from '../Theme';
import {APIBASEURL} from '../Constants/constants';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { AppContext } from '../Context/AppContext';

const ReportScreen = ({navigation, route}) => {
  //Global Context
  let {appData} = useContext(AppContext);

  const [missed, setMissed] = useState(0);
  const [scanned, setScanned] = useState(0);
  const [total, setTotal] = useState(0);
  const [csvData, setCsvData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false)

  useEffect(() => {
    getReportData();
  }, []);

  const getReportData = async () => {
    setLoading(true);
    // let accessKey = await AsyncStorage.getItem('access-key');
    fetch(appData.apiURL + '/get_report_data' + `?Authentication+key=RFD40+greenfuturzapi@`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        ...(appData.apiKey && {Authorization: appData.apiKey}),
      },
    })
      .then(async response => {
        let res = await response.json();
        // console.log(res);
        if (response.status == 200) {
          setTotal(res.data.total);
          setMissed(res.data.missed);
          setScanned(res.data.scanned);
          setCsvData(res.data.stock_items);
        } else {
          setError(true)
        }
      })

      .catch(error => setError(true))
      .finally(() => {
        setLoading(false);
      });
  };

  return (
    <SafeAreaView style={styles.mainContainer}>
      <StatusBar
        backgroundColor={'#EEFCF2'}
        barStyle={'dark-content'}
        hidden={false}
      />
      

      <View style={styles.topContainer}>
        <TouchableOpacity
          style={styles.topLeftContainer}
          onPress={() => {
            navigation.goBack();
          }}>
          <Back />
        </TouchableOpacity>
        <Text style={styles.headerStyle}> Report</Text>
      </View>
      <ScrollView>
      <View style={styles.reportInfoContainer}>
        <View style={styles.reportContent}>
          <ReportInfo
            title="Total"
            icon={<Total />}
            count={total}
            backgroundColor={'#F1F7FE'}
          />
          <ReportInfo
            title="Scanned"
            icon={<Scanned />}
            count={scanned}
            backgroundColor={Colors.Teritary}
          />
          <ReportInfo
            title="Missed"
            icon={<Missed />}
            count={missed}
            backgroundColor="#FCE3E3"
          />
        </View>
      </View>
      {error ? <View style={styles.loadingView}>
          <Text
            style={{
              marginTop: 20,
              fontSize: 16,
              fontFamily: 'Montserrat-SemiBold',
            }}>
            {'Oops Something Went Wrong...!'}
          </Text>
        </View> :
      (loading ? (
        <View style={styles.loadingView}>
          <ActivityIndicator size="large" color={'#000'} />
          <Text
            style={{
              marginTop: 20,
              fontSize: 16,
              fontFamily: 'Montserrat-SemiBold',
            }}>
            {'Fetching the Generated Report...!'}
          </Text>
        </View>
      ) : (
        <View style={{flex: 1}}>
          <ReportTable numItemsPerPage={10} csvData={csvData} isReport={true} />
        </View>
      ))}
      </ScrollView>
    </SafeAreaView>
  );
};

export default ReportScreen;
