import {StyleSheet} from 'react-native';

export default StyleSheet.create({
  mainContainer: {flex: 1, backgroundColor: '#fff'},
  topContainer: {
    height: '10%',
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
    backgroundColor: '#EEFCF2',
  },
  topLeftContainer: {
    flex: 0.25,
    marginLeft: 20,
    alignSelf: 'center',
    justifyContent: 'flex-start',
  },
  headerStyle: {
    alignSelf: 'center',
    flex: 0.75,
    color: '#000',
    fontSize: 16,
    fontFamily: 'Montserrat-SemiBold',
  },
  RFIDContainer: {
    backgroundColor: '#F7F7F7',
    flexDirection: 'row',
    margin: 10,
    borderRadius: 5,
    padding: 10,
    justifyContent: 'space-between',
    flex: 1,
  },
  RFIDTextStyle: {
    color: 'black',
    paddingRight: 20,
    flex: 1,
    fontSize: 14,
    fontFamily: 'Montserrat-SemiBold',
  },
  scanButtonStyle: {
    margin: 20,
    alignSelf: 'center',
    width: '90%',
    backgroundColor: '#25B54E',
    borderRadius: 5,
    padding: 10,
    alignItems: 'center',
  },
  reportInfoContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    paddingTop: 20,
    paddingBottom: 5,
    // borderBottomWidth: 1,
    // borderBottomColor: '#7B7B7B',
  },
  reportContent: {
    flex: 0.9,
  },
});
