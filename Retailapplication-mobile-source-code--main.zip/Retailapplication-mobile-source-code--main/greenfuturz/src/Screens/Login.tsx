import React, {useEffect, useState, useContext} from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  SafeAreaView,
  ScrollView,
  TextInput,
  ActivityIndicator,
Platform,
Keyboard
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import styles from './LoginStyles';

import LoginIcon1 from '../Assets/Images/loginIcon1.svg';
import LoginIcon2 from '../Assets/Images/loginIcon2.svg';
import Username from '../Assets/Images/username.svg';
import Password from '../Assets/Images/password.svg';
import PasswordInvisble from '../Assets/Images/passwordInvisible.svg';
import SplashScreen from 'react-native-splash-screen';
import {APIBASEURL} from '../Constants/constants';
import { AppContext } from '../Context/AppContext';


const LoginScreen = ({navigation, route}) => {

  //Global State
  let {appData, setAppData} = useContext(AppContext)

  let platform = Platform.OS;

  const [userName, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isPassVisible, setIsPassVisible] = useState(false);

  const [showLogin, setShowLogin] = useState(false);
  const [loading, setLoading] = useState(false);

  const [invalidUsername, setInvalidUsername] = useState(false);
  const [invalidPassword, setInvalidPassword] = useState(false);
  const [apiError, setApiError] = useState(false);
  const [apiErrorMessage, setApiErrorMessage] = useState('');

  const [keyboardStatus, setKeyboardStatus] = useState(false);
  const [isTapped, setIsTapped] = useState(1);


  useEffect(() => {
    const showSubscription = Keyboard.addListener('keyboardDidShow', () => {
      setKeyboardStatus(true);
    });
    const hideSubscription = Keyboard.addListener('keyboardDidHide', () => {
      setKeyboardStatus(false);
    });

    return () => {
      showSubscription.remove();
      hideSubscription.remove();
    };
  }, []);

  useEffect(() => {

    if (!appData.isKeyAndURlRetrieved) { // Check the key and URL in initial app opening
      getApiKeyAndURL();
    } else {
      setShowLogin(true) // This for once user logout showing login screen
    }
  
    // AsyncStorage.getItem('access-key').then(data => {
    //     //  setShowLogin(false);
    //     // navigation.replace('Home');
    //   if (data) {
    //     setShowLogin(false);
    //     navigation.replace('EndPointConfigScreen');
    //     setAppData((appdata)=> {
    //       return {...appdata, apiKey : data};
    //     })
    //   } else {
    //     setShowLogin(true);
    //   }
    //   SplashScreen.hide();
    // });
  },[]);

  async function getApiKeyAndURL() {
    try {
    let [apiKey, apiURL] = await Promise.all([AsyncStorage.getItem("access-key"), AsyncStorage.getItem("API_URL")]);
    if (apiKey) {
      setShowLogin(false);
      setAppData((appdata)=> {
        return {...appdata, apiKey: apiKey == "RFD40+greenfuturzapi@" ? "" : apiKey, ...(apiURL && {apiURL}), isKeyAndURlRetrieved : true};
      })
      navigation.replace('Home');
    } else {
      setAppData((appdata)=> {
        return {...appdata, ...(apiURL && {apiURL}), isKeyAndURlRetrieved : true};
      })
      setShowLogin(true);
    }
    // setAppData((appdata)=> {
    //   return {...appdata, ...(apiKey && {apiKey}), ...(apiURL && {apiURL})};
    // })
    // console.log("apikey and apiURL, ", apiKey, apiURL);
    !appData.isKeyAndURlRetrieved && SplashScreen.hide();

    } catch (error) {
      alert("Something went wrong in getting API key and URL");
    }

  }

  const setAPIErrorMessageText = (txt: string) => {
    setApiError(true);
    setApiErrorMessage(txt);
  };

  const onLogin = () => {

    if (appData.apiURL) {
      if (!userName.trim()) {
        setInvalidUsername(true);
        return;
      } else if (!password.trim()) {
        setInvalidUsername(false);
        setInvalidPassword(true);
        return;
      } else {
        setInvalidUsername(false);
        setInvalidPassword(false);
        setLoading(true);
        fetch(appData.apiURL + '/login', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            user: {
              email: userName,
              password: password,
            },
          }),
        })
          .then(async response => {
            let res = await response.json();
            // console.log(res);
            if (response.status == 200) {
             await AsyncStorage.setItem('access-key', res.data ? res.data : "RFD40+greenfuturzapi@");
              setAppData((appdata)=> {
                return {...appdata, apiKey: res.data ? res.data : ""};
              })
              navigation.replace('Home');
            } else {
              setAPIErrorMessageText(
                res?.error ? res?.error : 'Login Failed...!',
              );
            }
          })
  
          .catch(error => setAPIErrorMessageText('Login Failed...!'))
          .finally(() => {
            setLoading(false);
          });
      }

    } else {
      alert("Please configure the Endpoint")
    }
   
  };

  function endPointConfigScreen() {
    if (isTapped == 5) {
      setIsTapped(1);
      navigation.navigate("EndPointConfigScreen");
    } else {
      setIsTapped(isTapped + 1)
    }

  }

  return (
    <SafeAreaView style={styles.mainContainer}>
      {!showLogin ? null : (
        <ScrollView
          contentContainerStyle={{marginTop: (keyboardStatus && platform == "ios") ? 0 : '20%' }}
          keyboardShouldPersistTaps="handled">
          <TouchableOpacity style={{marginTop: (keyboardStatus && platform == "ios") ? 0 : 50, alignItems: 'center'}} onPress = {endPointConfigScreen} activeOpacity = {1}>
            <LoginIcon2 />
          </TouchableOpacity>
          <View style={{marginTop: (keyboardStatus && platform == "ios") ? 25 : 50, alignItems: 'center'}}>
            <LoginIcon1 />
          </View>
          {userName || password ? (
            <Text style={styles.inputHeaderStyle}>User Name</Text>
          ) : (
            <View style={{marginTop: 20}}></View>
          )}
          <View style={styles.passwordContainer}>
            <TextInput
              style={styles.inputStyle}
              onChangeText={username => {
                setApiError(false);
                setInvalidUsername(false);
                setUsername(username);
              }}
              underlineColorAndroid="rgba(0,0,0,0)"
              placeholder="User Name"
              placeholderTextColor="gray"
              value={userName}
            />
            <Username />
          </View>
          {invalidUsername ? (
            <Text style={styles.invalidPasswordStyle}>Enter the Username</Text>
          ) : null}
          {userName || password ? (
            <Text style={styles.inputHeaderStyle}>Password</Text>
          ) : (
            <View style={{marginTop: 20}}></View>
          )}
          <View style={styles.passwordContainer}>
            <TextInput
              style={styles.inputStyle}
              onChangeText={password => {
                setApiError(false);
                setInvalidPassword(false);
                setPassword(password);
              }}
              underlineColorAndroid="rgba(0,0,0,0)"
              placeholder="Password"
              secureTextEntry={!isPassVisible}
              placeholderTextColor="gray"
              value={password}
            />
            <TouchableOpacity
              onPress={() => {
                setIsPassVisible(!isPassVisible);
              }}>
              {isPassVisible ? <Password /> : <PasswordInvisble />}
            </TouchableOpacity>
          </View>
          {invalidPassword ? (
            <Text style={styles.invalidPasswordStyle}>Enter the Password</Text>
          ) : null}
          {apiError ? (
            <Text style={styles.apiErrorStyle}>{apiErrorMessage}</Text>
          ) : null}
          {/* <View style={styles.textContainer}>
            <Text
              style={styles.forgotPasswordStyle}
              onPress={() => {
                navigation.navigate('ChangePassword');
              }}>
              Reset Password
            </Text>
          </View> */}

          <TouchableOpacity
            style={styles.scanButtonStyle}
            onPress={() => {
              onLogin();
            }}>
            {loading ? (
              <ActivityIndicator color={'#fff'} />
            ) : (
              <Text
                style={{
                  color: '#fff',
                  fontFamily: 'Montserrat-SemiBold',
                  fontSize: 16,
                }}>
                Sign In
              </Text>
            )}
          </TouchableOpacity>
          <View style={{margin: '15%'}}></View>
        </ScrollView>
      )}
    </SafeAreaView>
  );
};

export default LoginScreen;
