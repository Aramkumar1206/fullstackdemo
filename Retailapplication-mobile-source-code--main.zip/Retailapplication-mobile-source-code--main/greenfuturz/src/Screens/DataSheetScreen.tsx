import AsyncStorage from '@react-native-async-storage/async-storage';
import React, {useEffect, useState, useContext} from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  SafeAreaView,
  ScrollView,
  StatusBar,
  ActivityIndicator,
  RefreshControl
} from 'react-native';
import Back from '../Assets/Images/back.svg';
import ReportTable from '../Components/ReportTable';
import { APIBASEURL } from '../Constants/constants';
import { AppContext } from '../Context/AppContext';

const DataSheetScreen = ({navigation, route}) => {
  // Global State
  let {appData} = useContext(AppContext);

  const [csvData, setCsvData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false)
  const [refreshing, setRefresing] = useState(false)

  useEffect(() => {
    // getLocalData();
    getCsvData();
  }, []);

  const getCsvData = async () => {
    // let accessKey = await AsyncStorage.getItem('access-key');
    fetch(`${appData.apiURL}/get_stock_items?Authentication+key=RFD40+greenfuturzapi@`,
    {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        ...(appData.apiKey && {Authorization: appData.apiKey}),
      }
    })
      .then(async response => {
        if(response.status == 200){
        const resp = await response.json();
        setCsvData(resp.data);}else{
          setError(true)
        }
      })
      .catch(error => {
        console.error('some error occurred', error);
        setError(true)

      })
      .finally(() => {
        setLoading(false);
        setRefresing(false)
      });
  };

  return (
    <SafeAreaView style={styles.mainContainer}>
      <StatusBar
        backgroundColor={'#EEFCF2'}
        barStyle={'dark-content'}
        hidden={false}
      />

      <View style={styles.topContainer}>
        <TouchableOpacity
          style={styles.topLeftContainer}
          onPress={() => {
            navigation.goBack();
          }}>
          <Back />
        </TouchableOpacity>
        <Text style={styles.headerStyle}> Imported data</Text>
      </View>
      {error ? <View style={styles.loadingView}>
          <Text
            style={{
              marginTop: 20,
              fontSize: 16,
              fontFamily: 'Montserrat-SemiBold',
            }}>
            {'Oops Something Went Wrong...!'}
          </Text>
        </View> :
      (loading ? (
        <View style={styles.loadingView}>
          <ActivityIndicator size="large" color={'#000'} />
          <Text
            style={{
              marginTop: 20,
              fontSize: 16,
              fontFamily: 'Montserrat-SemiBold',
            }}>
            {'Importing the sheet...!'}
          </Text>
        </View>
      ) : (
        <ScrollView style={{flex: 1}} refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={()=>{
            setRefresing(true)
            getCsvData()
            
          }} />
        }>
          <ReportTable
            numItemsPerPage={10}
            csvData={csvData}
            isReport={false}
          />
        </ScrollView>
      ))}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  mainContainer: {flex: 1},
  topContainer: {
    height: '10%',
    justifyContent: 'center',
    alignItems: 'center',
    // marginTop: 15,
    flexDirection: 'row',
    backgroundColor: '#EEFCF2',
  },
  topLeftContainer: {
    flex: 0.25,
    // flexDirection: 'row',
    marginLeft: 20,
    alignSelf: 'center',
    justifyContent: 'flex-start',
  },
  headerStyle: {
    alignSelf: 'center',
    flex: 0.75,
    color: '#000',
    fontSize: 16,
    fontFamily: 'Montserrat-SemiBold',
  },
  loadingView: {
    flex: 1,
    alignItems: 'center',
    alignContent: 'center',
    marginTop: 100,
  },
});
export default DataSheetScreen;
