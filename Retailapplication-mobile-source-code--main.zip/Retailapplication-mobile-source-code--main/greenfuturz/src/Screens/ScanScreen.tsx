import React, {useEffect, useState, useCallback, useContext} from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  SafeAreaView,
  StatusBar,
  FlatList,
  DeviceEventEmitter,
  ActivityIndicator,
  Alert,
  NativeEventEmitter,
  NativeModules,
  Platform
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import styles from './ScanScreenStyles';
import Back from '../Assets/Images/back.svg';
import Connected from '../Assets/Images/connected.svg';
import {APIBASEURL} from '../Constants/constants';
import Scanned from '../Assets/Images/scanned.svg';
import ReportInfo from '../Components/ReportInfo';
import ModalComponent from '../Components/ModalComponent';
import { useFocusEffect } from '@react-navigation/native';
import { AppContext } from '../Context/AppContext';

var {RFIDSDKModule} = NativeModules;
let todayDate = new Date()
let todayDateStr = `${todayDate.getDate().toString().length == 1 ? `0${todayDate.getDate()}` : todayDate.getDate()}/${(todayDate.getMonth() + 1).toString().length == 1 ? `0${todayDate.getMonth() + 1}` : todayDate.getMonth()}/${todayDate.getFullYear()}`
// let todayTimestamp = Date.now() / 1000;

const ScanScreen = ({navigation, route}) => {

  // Global state
  let {appData, setAppData} = useContext(AppContext);

  const {connectedRFID} = route.params;
  const [tagData, setTagData] = useState([]);
  const [tagId, setTagId] = useState(null);
  const [stopScan, setStopScan] = useState(false);
  const [loading, setLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [modalText, setModalText] = useState('');

  const isTagAlreadyScanned = (id: string) => {
    const isFound = tagData.some(tag => tag.id === id);
    if (isFound) return true;
    return false;
  };

  useFocusEffect(
    
    useCallback(() => {
      return () => {
        readTagEvent("Unlisten");
      };
    }, [])
  );

  useEffect(() => {
      let IOS_Event = Platform.OS == "ios" && new NativeEventEmitter(RFIDSDKModule);
      let onReceiveTagSubscriber = ( Platform.OS == "android" ? DeviceEventEmitter : IOS_Event).addListener(
        'onReceiveTag',
        onReceiveTag,
      ) 
      let onSessionDisconnectSubscriber = Platform.OS == "ios" && IOS_Event.addListener(
        'onSessionDisconnect',
        onSessionDisconnect,
      );
    
    return () => {
      onReceiveTagSubscriber.remove();
      Platform.OS == "ios" && onSessionDisconnectSubscriber.remove();
    };
  }, []);

  useEffect(() => {
    if (tagId && !stopScan) {
      if (isTagAlreadyScanned(tagId)) return;
      setTagData([
        ...tagData,
        {
          epc: tagId,
          status: 'scanned',
          timestamp : todayTimestamp()
        },
      ]);
    }
  }, [tagId]);

   // will be invoked Once received the tags
   const onReceiveTag = (tagId: string) => {
    setTagId(tagId);
  };

 // will be invoked Once disconnected
 const onSessionDisconnect = Disconnected => {
  setModalVisible(true);
  setModalText('Device Disconnected');
};

function todayTimestamp() {
  let date = new Date()
 return `${date.toLocaleString().slice(0,-3)}:${date.getMilliseconds()} ${date.toLocaleString().slice(-2)}`
}


  const onStopScan = async () => {
    setLoading(true);
    // let accessKey = await AsyncStorage.getItem('access-key');
    fetch(appData.apiURL + '/update_stock_status', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        ...(appData.apiKey && {Authorization: appData.apiKey}),
      },
      body: JSON.stringify({
        reader_name : `${connectedRFID} RFID Reader`,
        "Authentication key" : "RFD40+greenfuturzapi@",
        "tag_reads" : tagData
        // stock_items: tagData,
      }),
    })
      .then(async response => {
        let res = await response.json();
        if (response.status == 200) {
          setStopScan(true);
        } else {
          setModalVisible(true);
          setModalText(
            res?.error ? res?.error : 'Oops Something Went Wrong...!',
          );
        }
      })

      .catch(error => {
        setModalVisible(true);
        setModalText('Oops Something Went Wrong...!');
      })
      .finally(() => {
        setLoading(false);
      });
  };

  

  async function readTagEvent(event) {
    try {
    await RFIDSDKModule.readTagEvents(event);
    } catch (error) {
      return null;
    }
  }

  return (
    <SafeAreaView style={styles.mainContainer}>
      <StatusBar
        backgroundColor={'#EEFCF2'}
        barStyle={'dark-content'}
        hidden={false}
      />
      <ModalComponent
        modalVisible={modalVisible}
        setModalVisible={param => {
          setModalVisible(param);
        }}
        errorText={modalText}
      />
      <View style={styles.topContainer}>
        <TouchableOpacity
          style={styles.topLeftContainer}
          onPress={() => {
            navigation.goBack();
          }}>
          <Back />
        </TouchableOpacity>
        <Text style={styles.headerStyle}> {connectedRFID}</Text>
      </View>
      <View style={styles.reportInfoContainer}>
        <View style={styles.reportContent}>
          <ReportInfo
            title="Scanned"
            icon={<Scanned />}
            count={tagData && tagData.length}
            backgroundColor={'#F1F7FE'}
          />
        </View>
      </View>
      <FlatList
        data={tagData}
        renderItem={({item, index}) => {
          return (
            <View style={styles.RFIDContainer}>
              <Text style={styles.RFIDTextStyle}>RFID No : {item.epc}</Text>
              <View style={{alignSelf: 'center'}}>
                <Connected />
              </View>
            </View>
          );
        }}
      />

      {!stopScan ? (
        <TouchableOpacity
          style={[
            styles.scanButtonStyle,
            {backgroundColor: tagData.length > 0 ? '#25B54E' : 'gray'},
          ]}
          onPress={() => {
            if (tagData.length > 0) {
              onStopScan();
            } else {
              setModalVisible(true);
              setModalText('Please scan tag');
              // Alert.alert('Please scan tag');
            }
          }}>
          {loading ? (
            <ActivityIndicator color={'#fff'} />
          ) : (
            <Text
              style={{
                color: '#fff',
                fontSize: 14,
                fontFamily: 'Montserrat-SemiBold',
              }}>
              Stop
            </Text>
          )}
        </TouchableOpacity>
      ) : (
        <TouchableOpacity
          style={styles.scanButtonStyle}
          onPress={() => {
            navigation.replace('ReportScreen');
          }}>
          {loading ? (
            <ActivityIndicator color={'#fff'} />
          ) : (
            <Text
              style={{
                color: '#fff',
                fontSize: 14,
                fontFamily: 'Montserrat-SemiBold',
              }}>
              Generate Report
            </Text>
          )}
        </TouchableOpacity>
      )}
    </SafeAreaView>
  );
};

export default ScanScreen;
