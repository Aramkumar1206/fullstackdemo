import React, { useEffect, useState, useContext } from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  SafeAreaView,
  ScrollView,
  TextInput,
  ActivityIndicator,
  StatusBar
} from 'react-native';
import styles from './ChangePasswordStyles';

import LoginIcon1 from '../Assets/Images/loginIcon1.svg';
import LoginIcon2 from '../Assets/Images/loginIcon2.svg';
import Password from '../Assets/Images/password.svg';
import Back from '../Assets/Images/back.svg';
import PasswordInvisble from '../Assets/Images/passwordInvisible.svg';
import { APIBASEURL } from '../Constants/constants';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { AppContext } from '../Context/AppContext';

const ChangePassword = ({ navigation, route }) => {
  // Global State
  const { appData } = useContext(AppContext);

  // const {token} = route.params
  const [currPassword, setCurrPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isPassVisible, setIsPassVisible] = useState(false);

  const [loading, setLoading] = useState(false);

  const [invalidCurrPassword, setInvalidCurrPassword] = useState(false);
  const [invalidNewPassword, setInvalidNewPassword] = useState(false);
  const [invalidConfirmPassword, setInvalidConfirmPassword] = useState(false);
  const [apiError, setApiError] = useState(false);
  const [apiErrorMessage, setApiErrorMessage] = useState('');
  const [resetted, setResetted] = useState(false);

  // useEffect(() => {
  //   // Check Already Logged In
  // });


  const setAPIErrorMessageText = (txt: string) => {
    setApiError(true);
    setApiErrorMessage(txt);
  };

  const onSubmit = async () => {
    if (!currPassword.trim()) {
      setInvalidCurrPassword(true);
      return;
    } else if (!newPassword.trim()) {
      setInvalidCurrPassword(false);
      setInvalidNewPassword(true);
      return;
    } else if (!confirmPassword.trim()) {
      setInvalidCurrPassword(false);
      setInvalidNewPassword(false);
      setInvalidConfirmPassword(true);
      return;
    } else {
      setInvalidCurrPassword(false);
      setInvalidNewPassword(false);
      setInvalidConfirmPassword(false);
      if (newPassword != confirmPassword) {
        setAPIErrorMessageText("Password doesn't match")
        return
      }
      setLoading(true);
      // let accessKey = await AsyncStorage.getItem('access-key');
      fetch(`${appData.apiURL}/update_new_password`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          ...(appData.apiKey && {Authorization: appData.apiKey})
        },
        body: JSON.stringify(
          {
              current_password: currPassword,
              password: newPassword,
              password_confirmation: confirmPassword,
              "Authentication key": "RFD40+greenfuturzapi@"
          }
        ),
      })
        .then(async response => {
          let res = await response.json();
          // console.log(res);
          if (response.status == 200) {
            setResetted(true);
          } else {
            setAPIErrorMessageText(
              res?.error ? res?.error : 'Reset Password Failed...!',
            );
          }
        })

        .catch(error => setAPIErrorMessageText('Reset Password Failed...!'))
        .finally(() => {
          setLoading(false);
          //   setResetted(true);
        });
    }
  };

  return (
    <SafeAreaView style={styles.mainContainer}>
      <StatusBar
        backgroundColor={'#EEFCF2'}
        barStyle={'dark-content'}
        hidden={false}
      />
      <View style={styles.topContainer}>
        <TouchableOpacity
          style={styles.topLeftContainer}
          onPress={() => {
            navigation.goBack();
          }}>
          <Back />

        </TouchableOpacity>
        <Text style={styles.headerTextStyle}>Reset Password</Text>

      </View>
      <ScrollView
        contentContainerStyle={{ alignItems: 'center', marginTop: '5%' }}
        keyboardShouldPersistTaps="handled">
        <View style={{ marginTop: 10, alignItems: 'center' }}>
          <LoginIcon2 />
        </View>
        <View style={{ marginTop: 20, alignItems: 'center' }}>
          <LoginIcon1 />
        </View>
        {resetted ? (
          <>
            <Text
              style={{
                color: '#25B54E',
                fontFamily: 'Montserrat-SemiBold',
                fontSize: 16,
                marginTop: 30,
              }}>
              {'Password Changed Successfully !!'}
            </Text>
            <TouchableOpacity
              style={styles.scanButtonStyle}
              onPress={() => {
                navigation.goBack();
              }}>
              <Text
                style={{
                  color: '#fff',
                  fontFamily: 'Montserrat-SemiBold',
                  fontSize: 16,
                }}>
                Go Back
              </Text>
            </TouchableOpacity>
          </>
        ) : (
          <>
            {newPassword || confirmPassword || currPassword ? (
              <Text style={styles.inputHeaderStyle}>Current Password</Text>
            ) : (
              <View style={{ marginTop: 20 }}></View>
            )}
            <View style={styles.passwordContainer}>
              <TextInput
                style={styles.inputStyle}
                onChangeText={currPassword => {
                  setApiError(false);
                  setInvalidCurrPassword(false);
                  setCurrPassword(currPassword);
                }}
                underlineColorAndroid="rgba(0,0,0,0)"
                placeholder="Current password"
                placeholderTextColor="gray"
                secureTextEntry={!isPassVisible}
                value={currPassword}
              />
              <TouchableOpacity
                onPress={() => {
                  setIsPassVisible(!isPassVisible);
                }}>
                {isPassVisible ? <Password /> : <PasswordInvisble />}
              </TouchableOpacity>
            </View>
            {invalidCurrPassword ? (
              <Text style={styles.invalidPasswordStyle}>Enter the Current Password</Text>
            ) : null}
            {newPassword || confirmPassword || currPassword ? (
              <Text style={styles.inputHeaderStyle}>New Password</Text>
            ) : (
              <View style={{ marginTop: 20 }}></View>
            )}
            <View style={styles.passwordContainer}>
              <TextInput
                style={styles.inputStyle}
                onChangeText={newPassword => {
                  setApiError(false);
                  setInvalidNewPassword(false);
                  setNewPassword(newPassword);
                }}
                underlineColorAndroid="rgba(0,0,0,0)"
                placeholder="New password"
                placeholderTextColor="gray"
                secureTextEntry={!isPassVisible}
                value={newPassword}
              />
              <TouchableOpacity
                onPress={() => {
                  setIsPassVisible(!isPassVisible);
                }}>
                {isPassVisible ? <Password /> : <PasswordInvisble />}
              </TouchableOpacity>
            </View>
            {invalidNewPassword ? (
              <Text style={styles.invalidPasswordStyle}>Enter the New Password</Text>
            ) : null}
            {newPassword || confirmPassword || currPassword ? (
              <Text style={styles.inputHeaderStyle}>Confirm Password</Text>
            ) : (
              <View style={{ marginTop: 20 }}></View>
            )}
            <View style={styles.passwordContainer}>
              <TextInput
                style={styles.inputStyle}
                onChangeText={confirmPassword => {
                  setApiError(false);
                  setInvalidConfirmPassword(false);
                  setConfirmPassword(confirmPassword);
                }}
                underlineColorAndroid="rgba(0,0,0,0)"
                placeholder="Confirm Password"
                secureTextEntry={!isPassVisible}
                placeholderTextColor="gray"
                value={confirmPassword}
              />
              <TouchableOpacity
                onPress={() => {
                  setIsPassVisible(!isPassVisible);
                }}>
                {isPassVisible ? <Password /> : <PasswordInvisble />}
              </TouchableOpacity>
            </View>
            {invalidConfirmPassword ? (
              <Text style={styles.invalidPasswordStyle}>Enter the Confirm Password</Text>
            ) : null}
            {apiError ? (
              <Text style={styles.apiErrorStyle}>{apiErrorMessage}</Text>
            ) : null}


            <TouchableOpacity
              style={styles.scanButtonStyle}
              onPress={() => {
                onSubmit();
              }}>
              {loading ? (
                <ActivityIndicator color={'#fff'} />
              ) : (
                <Text
                  style={{
                    color: '#fff',
                    fontFamily: 'Montserrat-SemiBold',
                    fontSize: 16,
                  }}>
                  Submit
                </Text>
              )}
            </TouchableOpacity>
            <View style={{ margin: '15%' }}></View>
          </>)}
      </ScrollView>

    </SafeAreaView>
  );
};

export default ChangePassword;
