import {StyleSheet} from 'react-native';
import {Colors, horizontalScale, verticalScale} from '../Theme';
export default StyleSheet.create({
    mainContainer: {
        flex: 1,
        alignItems : "center",
        backgroundColor : "white"
    },
    topContainer: {
      height: verticalScale(75),
      flexDirection: 'row',
      backgroundColor: '#EEFCF2',
    },
    topLeftContainer: {
      flex: 0.25,
      // flexDirection: 'row',
      marginLeft: 20,
      alignSelf: 'center',
      justifyContent: 'flex-start',
    },
    headerStyle: {
      justifyContent: 'center',
      alignSelf: 'center',
      flex: 0.75,
      color: '#000',
      fontSize: 16,
      fontFamily: 'Montserrat-SemiBold',
    },
    endPointInputTitle : {
        marginVertical : verticalScale(20),
        alignSelf : "flex-start",
        fontFamily : "Montserrat-Medium",
        color : Colors.TextPrimary,
        marginLeft : "2.5%"
    },
    endPointInputField : {
        height : verticalScale(60),
        width : "95%",
        backgroundColor : "#F7F7F7",
        fontSize : verticalScale(18),
        fontFamily : "Montserrat-SemiBold",
        paddingLeft : horizontalScale(10),
        borderRadius : horizontalScale(5)
    },
    saveAndEditButton : {
        width : horizontalScale(120),
        height : verticalScale(50)
    },
    saveButtonContainer : {
        marginTop : verticalScale(20),
    },
    saveButtonText : {
        fontSize : verticalScale(18),
        fontFamily : "Montserrat-SemiBold",
    },
    invalidUrlText : {
        fontFamily : "Montserrat-Medium",
        color : "red",
        marginTop: verticalScale(5),
        alignSelf : "flex-start",
        marginLeft : "2.5%"
    }
    
    
    

    
});