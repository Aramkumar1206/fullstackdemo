import { StyleSheet, Text, View, TouchableOpacity, TextInput, ActivityIndicator } from 'react-native'
import React, { useState, useContext, useEffect, useRef } from 'react'
import { Button } from 'react-native-paper';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Back from '../Assets/Images/back.svg';
import styles from "./EndPointConfigStyles"
import { Colors, verticalScale } from '../Theme';
import { AppContext } from '../Context/AppContext';

const EndPointConfigScreen = ({ navigation }) => {

  //Global State
  const { appData, setAppData } = useContext(AppContext)

  const [initialLoader, setInitialLoader] = useState(false)
  const [endPoint, setEndPoint] = useState({
    url: "",
    isValid: "",
    loading: false,
    isStoredOrRetrieved: false,
    isEditable: true
  })


  //Constant
  const urlPattern =
    /(https:\/\/www\.|http:\/\/www\.|https:\/\/|http:\/\/)?[a-zA-Z]{2,}(\.[a-zA-Z]{2,})(\.[a-zA-Z]{2,})?\/[a-zA-Z0-9]{2,}|((https:\/\/www\.|http:\/\/www\.|https:\/\/|http:\/\/)?[a-zA-Z]{2,}(\.[a-zA-Z]{2,})(\.[a-zA-Z]{2,})?)|(https:\/\/www\.|http:\/\/www\.|https:\/\/|http:\/\/)?[a-zA-Z0-9]{2,}\.[a-zA-Z0-9]{2,}\.[a-zA-Z0-9]{2,}(\.[a-zA-Z0-9]{2,})?/g;

  //Reference
  const inputRef = useRef();

  useEffect(() => {
    setInitialLoader(true);
    if (appData.apiURL) { // if apiURL already retrieved means set in the endpoint state
      setEndPoint({
        ...endPoint,
        url : appData.apiURL,
        isStoredOrRetrieved: true,
        isEditable: false
      })
    }
    setTimeout(()=> {
      setInitialLoader(false);
    }, 500)
    // console.log(appData, "app")
    // storeOrRetrieveEndPoint("Retrieve");
  }, [])

  
  function endPointInput(input) {
    setEndPoint({
      ...endPoint, url: input
    })
  }

  function saveOrEditEndPoint() {
    if (endPoint.isStoredOrRetrieved) { // Click the button for Edit
      // console.log("Click the button for Edit")
      setEndPoint({
        ...endPoint, isStoredOrRetrieved: false, isEditable: true // Make the button text to Save and Input is Editable
      })
      // inputRef.current.focus();

    } else { // Click the button for Save
      if (urlPattern.test(endPoint.url)) {
        setEndPoint({
          ...endPoint, loading: true
        })
        storeEndPoint();
      } else {
        setEndPoint({
          ...endPoint, isValid: false
        })
      }

    }

  }

  async function storeEndPoint() {
    try {
    // Store and Edit the URL
        await AsyncStorage.setItem("API_URL", endPoint.url);
        setEndPoint({
          ...endPoint, loading: false, isStoredOrRetrieved: true, isEditable: false, isValid: true,
        })
        setAppData({
          ...appData, apiURL: endPoint.url
        })
        // console.log("Stored")

      // else { // Retrieve the URL
      //   let apiURL = await AsyncStorage.getItem("API_URL");
      //   if (apiURL) {
      //     setEndPoint({
      //       ...endPoint, isStoredOrRetrieved: true, url: apiURL, isEditable: false
      //     })
      //     console.log("Retrieved")
      //   } else {
      //     console.log("No URL is stored")
      //   }

      //   setInitialLoader(false);

      // }
    } catch (error) {
      alert("Something went wrong in storing the URL");
     setEndPoint({
        ...endPoint, loading: false
      }) 

    }
  }

  return (
    <View style={styles.mainContainer}>

      <View style={styles.topContainer}>
        <TouchableOpacity
          style={styles.topLeftContainer}
          onPress={() => {
            navigation.goBack();
          }}>
          <Back />
        </TouchableOpacity>
        <Text style={styles.headerStyle}>End Point Config</Text>
      </View>
      {initialLoader ? <ActivityIndicator size="large" color={Colors.Primary} style={{ marginTop: verticalScale(10) }} /> : (
        <>
          <Text style={styles.endPointInputTitle}>End Point:</Text>

          <TextInput
            style={styles.endPointInputField}
            onChangeText={endPointInput}
            value={endPoint.url}
            placeholder="Enter the EndPoint"
            ref={inputRef}
            editable={endPoint.isEditable}
          />
          <Text style={styles.invalidUrlText}>{endPoint.isValid === false ? "Enter the Valid URL" : null}</Text>

          <Button mode="contained" onPress={saveOrEditEndPoint} loading={endPoint.loading} buttonColor={Colors.Primary} contentStyle={styles.saveAndEditButton} disabled={endPoint.url ? false : true} style={styles.saveButtonContainer} labelStyle={styles.saveButtonText}>
            {endPoint.isStoredOrRetrieved ? "Edit" : "Save"}
          </Button>
        </>
      )}




    </View>

  )
}

export default EndPointConfigScreen;

