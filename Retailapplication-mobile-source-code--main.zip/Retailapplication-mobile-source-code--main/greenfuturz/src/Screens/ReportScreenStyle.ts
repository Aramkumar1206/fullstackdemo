import {StyleSheet} from 'react-native';
import {Colors, verticalScale} from '../Theme';
export default StyleSheet.create({
  mainContainer: {flex: 1},
  topContainer: {
    height: '10%',
    flexDirection: 'row',
    backgroundColor: '#EEFCF2',
  },
  topLeftContainer: {
    flex: 0.25,
    // flexDirection: 'row',
    marginLeft: 20,
    alignSelf: 'center',
    justifyContent: 'flex-start',
  },
  headerStyle: {
    justifyContent: 'center',
    alignSelf: 'center',
    flex: 0.75,
    color: '#000',
    fontSize: 16,
    fontFamily: 'Montserrat-SemiBold',
  },
  reportInfoContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    paddingTop: verticalScale(20),
    paddingBottom: verticalScale(5),
    borderBottomWidth: 1,
    borderBottomColor: '#7B7B7B',
  },
  reportContent: {
    flex: 0.9,
  },
  loadingView: {
    flex: 1,
    alignItems: 'center',
    // justifyContent: 'center',
    alignContent: 'center',
    marginTop: 100,
  },
});
