import React from 'react';

import {createNativeStackNavigator} from '@react-navigation/native-stack';

import HomeScreen from '../Screens/HomeScreen';
import DataSheetScreen from '../Screens/DataSheetScreen';
import ScanScreen from '../Screens/ScanScreen';
import ReportScreen from '../Screens/ReportScreen';
import LoginScreen from '../Screens/Login';
import ForgotPasswordScreen from '../Screens/ForgotPasswordScreen';
import ChangePassword from '../Screens/ChangePassword';
import EndPointConfigScreen from '../Screens/EndPointConfigScreen';
const Stack = createNativeStackNavigator();

const ApplicationNavigator = () => {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
        // presentation: 'modal',
        animationTypeForReplace: 'push',
        // animation: 'slide_from_right',
      }}>
      <Stack.Screen name="LoginScreen" component={LoginScreen} options={{orientation: 'portrait'}} />
      <Stack.Screen name="ForgotPasswordScreen" component={ForgotPasswordScreen} options={{orientation: 'portrait'}} />
      <Stack.Screen name="ChangePassword" component={ChangePassword} options={{orientation: 'portrait'}} />
      <Stack.Screen name="Home" component={HomeScreen} options={{orientation: 'portrait'}} />
      <Stack.Screen name="EndPointConfigScreen" component={EndPointConfigScreen} options={{orientation: 'portrait'}} />
      <Stack.Screen name="DataSheetScreen" component={DataSheetScreen} options={{orientation: 'all'}}  />
      <Stack.Screen name="ScanScreen" component={ScanScreen} options={{orientation: 'portrait'}} />
      <Stack.Screen name="ReportScreen" component={ReportScreen} options={{orientation: 'all'}} />
    </Stack.Navigator>
  );
};

export default ApplicationNavigator;
