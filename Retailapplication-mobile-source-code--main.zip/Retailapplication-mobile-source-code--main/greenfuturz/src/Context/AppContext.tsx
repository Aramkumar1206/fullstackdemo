import React, {createContext, useState, useMemo} from "react"

const AppContext = createContext();


function AppContextProvider({children}) {
    
    let [appData, setAppData] = useState({
        apiKey : "",
        apiURL : "",
        isKeyAndURlRetrieved : false
    });

    let data = useMemo(()=> {
        return {appData, setAppData};
    }, [appData])

    return (
        <AppContext.Provider value = {data}>
            {children}
        </AppContext.Provider>
       
    );

}

export {AppContextProvider, AppContext}