

export const APIBASEURL = 'https://greenfuturz.spritle.com/api/v1'

// export const APIBASEURL = 'https://greenfuturz-test.spritle.com/api/v1'