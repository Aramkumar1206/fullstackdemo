//
//  RCTRFIDReaderModule.m
//  greenfuturz
//
//  Created by SPRITLE on 24/07/23.
//

#import <Foundation/Foundation.h>
#import <React/RCTLog.h>
#import "RCTRFIDSDK1Module.h"
//#import "RfidAppEngine.h"
#import "Constants.h"

@implementation RCTRFIDSDK1Module
//RfidAppEngine * m_rfidSdk;
//
//
//// To export a module named RCTRFIDSDKModule
//RCT_EXPORT_MODULE();
//
//
//
//
//// Initialize the SDK
//RCT_EXPORT_METHOD(initializeReaderSdk)
//{
//  m_rfidSdk = [[RfidAppEngine alloc] init];
//}
//
//RCT_EXPORT_METHOD(triggerEvent) {
//  [m_rfidSdk checkEvent];
//}
//
// Get The Available Reader Devices
//RCT_EXPORT_METHOD(getAvailableDevices :(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject)
//{
// NSMutableDictionary * readerDevices = [m_rfidSdk getAvialableReaderList];
//
////  NSLog(@"Reader devices count is %lu",count);
//  if ([readerDevices count] != 0) {
//    NSDictionary *availableReaders = [NSDictionary dictionaryWithDictionary:readerDevices];
//    rfidReaderDevices = readerDevices;
//    resolve(availableReaders);
//
//  } else {
//    reject(@"No Devices", @"No Reader Devices Available", nil);
//
//  }
//
//}
//
////Connect the device
//RCT_EXPORT_METHOD(connectReaderDevice :(NSString *)readerName resolver:(RCTPromiseResolveBlock)resolve
//                  rejecter:(RCTPromiseRejectBlock)reject) {
//  int readerId = [[rfidReaderDevices valueForKey: readerName] intValue];
//
//  NSString *connectionStatus = [m_rfidSdk connect:readerId];
//  if ([connectionStatus isEqualToString : @"Connected"]) {
//
//    NSString *readerConfigStatus = [m_rfidSdk setAntennaAndSingulationConfig]; //After connection successfull set the antenna and singulation config
//
//    if ([readerConfigStatus isEqualToString: @"Success"]) {
//      resolve(@"Connected");
//    } else {
//      resolve(@"");
//    }
//
//  } else {
//    resolve(@"");
//  }
//}
//
////Disconnect the device
//RCT_EXPORT_METHOD(disconnectReaderDevice :(NSString *)readerName resolver:(RCTPromiseResolveBlock)resolve
//                  rejecter:(RCTPromiseRejectBlock)reject) {
//
//  int readerId = [[rfidReaderDevices valueForKey: readerName] intValue];
//  NSString *disconnectStatus = [m_rfidSdk disconnect:readerId];
//  if ([disconnectStatus isEqualToString : @"Disconnected"]) {
//    resolve(@"Disconnected");
//  } else {
//    resolve(@"Disconnect failed");
//  }
//
//}
//
////Start Inventory operation to perform the tag reading operation
//RCT_EXPORT_METHOD(readTagEvents: (NSString *)event resolver:(RCTPromiseResolveBlock)resolve
//                  rejecter:(RCTPromiseRejectBlock)reject) {
//
//  NSString *operationStatus;
//  if ([event isEqualToString: @"Listen"]) {
//    operationStatus = [m_rfidSdk startInventory];
//    if ([operationStatus isEqualToString: SUCCESS]) {
//      resolve(SUCCESS);
//    } else {
//      reject(OPERATION_FAILED, @"Read tag listen event failed", nil);
//    }
//
//  } else {
//    operationStatus = [m_rfidSdk stopInventory];
//    if ([operationStatus isEqualToString: SUCCESS]) {
//      resolve(SUCCESS);
//    } else {
//      reject(OPERATION_FAILED, @"Read tag unlisten event failed", nil);
//    }
//  }
//}


@end
