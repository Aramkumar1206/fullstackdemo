//
//  RCTRFIDReaderModule.h
//  greenfuturz
//
//  Created by SPRITLE on 24/07/23.
//

#ifndef RCTRFIDReaderModule_h
#define RCTRFIDReaderModule_h
#import <React/RCTBridgeModule.h>
#import <React/RCTEventEmitter.h>
//#import "RfidAppEngine.h"


@interface RCTRFIDSDK1Module : NSObject  {
//  RfidAppEngine * m_rfidSdk;
//  NSMutableDictionary *rfidReaderDevices;
}

@end



#endif /* RCTRFIDReaderModule_h */
