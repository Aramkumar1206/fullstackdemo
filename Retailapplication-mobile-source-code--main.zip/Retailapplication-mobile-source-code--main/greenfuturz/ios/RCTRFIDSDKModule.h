//
//  RfidAppEngine.h
//  greenfuturz
//
//  Created by SPRITLE on 25/07/23.
//

#ifndef RfidAppEngine_h
#define RfidAppEngine_h
#import <React/RCTEventEmitter.h>
#import <React/RCTBridgeModule.h>
#import "RfidSdkApiDelegate.h"
#


@interface RCTRFIDSDKModule : RCTEventEmitter <srfidISdkApiDelegate, RCTBridgeModule> {
  
//  NSMutableDictionary * readersInfo;
  NSMutableDictionary *rfidReaderDevices;
  int _connectedReaderId;
  srfidReaderInfo *connectedReaderInfo;
  
//  bool hasListeners;
  
}

//@property(nonatomic, readwrite) NSMutableDictionary * readersInfo;
//@property(nonatomic, readwrite) int _connectedReaderId;


//+ (RfidAppEngine *) sharedAppEngine;
//+ (id)alloc;
+ (void)destroy;
//- (id)init;
- (void)dealloc;

- (void)initializeRfidSdkWithAppSettings;
- (NSMutableDictionary *)getAvialableReaderList;
- (void)connect:(int)reader_id;
- (NSString *)disconnect:(int)reader_id;
- (void)setAntennaAndSingulationConfig;
- (NSString *) startInventory;
- (NSString *) stopInventory;
- (void) checkEvent;
-(void) triggerConfigAndStartInventory;
@end


#endif /* RfidAppEngine_h */
