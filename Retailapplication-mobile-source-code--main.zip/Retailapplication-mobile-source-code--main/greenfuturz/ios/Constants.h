//
//  Constants.h
//  greenfuturz
//
//  Created by SPRITLE on 31/07/23.
//

#ifndef Constants_h
#define Constants_h

#define SUCCESS @"Success"
#define FAILED @"Failed"
#define OPERATION_FAILED @"Operation Failed"


#endif /* Constants_h */
