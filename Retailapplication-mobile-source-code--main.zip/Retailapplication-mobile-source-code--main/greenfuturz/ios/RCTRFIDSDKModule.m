//
//  RfidAppEngine.m
//  greenfuturz
//
//  Created by SPRITLE on 25/07/23.
//

#import <Foundation/Foundation.h>
#import <React/RCTLog.h>
#import "RCTRFIDSDKModule.h"
#import "RfidSdkApi.h"
#import "RfidAntennaConfiguration.h"
#import "RfidSdkFactory.h"
#import "RfidRegionInfo.h"
#import "RfidReaderInfo.h"
#import "RfidLinkProfile.h"
#import "RfidTagData.h"
#import "Constants.h"

#define SETTING_OPMODE                      @"SymbolRfidAppCfgOpMode"

RCTRFIDSDKModule *_g_RCTRFIDSDKModule;

@interface RCTRFIDSDKModule()
{
//    zt_SledConfiguration *m_SledConfiguration;
//    zt_AppConfiguration *m_AppConfiguration;
//    zt_ActiveReader *m_ActiveReader;
//    zt_SledConfiguration *m_TemporarySledConfigurationCopy;
//    zt_InventoryData *m_InventoryData;
//
    id <srfidISdkApi> m_RfidSdkApi;
    srfidSingulationConfig *configured_singulation;
    SRFID_INVENTORYSTATE inventoryState;
    srfidReportConfig *report_cfg;

  /* allocate object for access parameters of inventory operation */
    srfidAccessConfig *access_cfg;
//    NSMutableArray *readers;
   
//    NSMutableArray *m_DeviceInfoList;
//    NSLock *m_DeviceInfoListGuard;
//
//    NSMutableArray *m_DevListDelegates;
//    NSMutableArray *m_ReadEventListDelegates;
//    NSMutableArray *m_TriggerEventDelegates;
//    NSMutableArray *m_BatteryEventDelegates;
//
//    NSMutableArray *multiTagEventDelegates;
//
//    /* nrv364: stores last battery event info */
//    srfidBatteryEvent *m_BatteryInfo;
//    NSMutableString *m_BatteryStatusStr;
//    NSLock *m_BatteryInfoGuard;
//
//    zt_RadioOperationEngine *m_RadioOperationEngine;
}

-(NSString *)setSingulationConfig;
//- (void)fillDeviceList:(NSMutableArray**)list;
//- (void)updateInitialSledConfiguration;
//- (void)initializeRfidSdkWithAppSettings;
//- (int)showBackgroundNotification:(NSString *)text aDictionary:(NSDictionary*)param_dict;
//- (void)showMessageBox:(NSString*)message;
//- (BOOL)isInBackgroundMode;
//- (NSString*)stringOfRfidStatusEvent:(SRFID_EVENT_STATUS)event;
//- (NSString*)stringOfRfidMemoryBank:(SRFID_MEMORYBANK)mem_bank;
//- (NSString*)stringOfRfidSlFlag:(SRFID_SLFLAG)sl_flag;
//- (NSString*)stringOfRfidSession:(SRFID_SESSION)session;
//- (NSString*)stringOfRfidInventoryState:(SRFID_INVENTORYSTATE)state;
//
///* test/debug */
//- (void)printInventoryItems;
//
@end

@implementation RCTRFIDSDKModule

//+ (RfidAppEngine *) sharedAppEngine
//{
//    @synchronized([RfidAppEngine class])
//    {
//        if (_g_sharedAppEngine == nil)
//        {
//            [[self alloc] init];
//        }
//
//        return _g_sharedAppEngine;
//    }
//    return nil;
//}

// To export a module named RCTRFIDSDKModule
RCT_EXPORT_MODULE();

//+(id)alloc
//{
//    @synchronized([RCTRFIDSDKModule class])
//    {
//      NSLog(@"Allocation");
//        NSAssert(_g_RCTRFIDSDKModule == nil, @"Attempted to allocate a second instance of a singleton.");
//        _g_RCTRFIDSDKModule = [super alloc];
//        return _g_RCTRFIDSDKModule;
//    }
//    return nil;
//}

+(void)destroy
{
//    @synchronized([RfidAppEngine class])
//    {
//        if (_g_sharedAppEngine != nil)
//        {
////            [_g_sharedAppEngine dealloc];
//        }
//    }
}

//-(id)init
//{
//    self = [super init];
//    if (self != nil)
//    {
//          /* merge active and available readers to a single list */
//
//
////        m_SledConfiguration = [[zt_SledConfiguration alloc] init];
////        /*
////         TBD: sled configuration shall be downloaded from active
////         sled on connection establishment
////         */
////        [m_SledConfiguration setupInitialConfiguration];
////
////        m_TemporarySledConfigurationCopy = [[zt_SledConfiguration alloc] init];
////        [m_TemporarySledConfigurationCopy setupInitialConfiguration];
////
////        m_AppConfiguration = [[zt_AppConfiguration alloc] init];
////        [m_AppConfiguration loadAppConfiguration];
//
////        m_DeviceInfoList = [[NSMutableArray alloc] init];
////        m_DeviceInfoListGuard = [[NSLock alloc] init];
////        m_DevListDelegates = [[NSMutableArray alloc] init];
////
////        m_ReadEventListDelegates = [[NSMutableArray alloc] init];
////
////        m_ActiveReader = [[zt_ActiveReader alloc] init];
////        [m_ActiveReader setIsActive:NO withID:nil];
////        [m_ActiveReader setBatchModeStatus:NO];
////
////        m_InventoryData = [[zt_InventoryData alloc] init];
////
////        m_TriggerEventDelegates = [[NSMutableArray alloc] init];
////        m_BatteryEventDelegates = [[NSMutableArray alloc] init];
////        multiTagEventDelegates = [[NSMutableArray alloc] init];
////
////        m_BatteryInfo = [[srfidBatteryEvent alloc] init];
////        m_BatteryStatusStr = [[NSMutableString alloc] initWithString:@""];
////        m_BatteryInfoGuard = [[NSLock alloc] init];
////
////        m_RadioOperationEngine = [[zt_RadioOperationEngine alloc] init];
//      RCTLogInfo(@"Initialiazing the SDK");
////        [self initializeRfidSdkWithAppSettings];
//
//    }
//
//    return self;
//}

- (void)dealloc
{
    /* release all allocated for singleton objects */
    
//    if (nil != m_SledConfiguration)
//    {
//        [m_SledConfiguration release];
//    }
//    if (nil != m_AppConfiguration)
//    {
//        [m_AppConfiguration release];
//    }
//
//    if (nil != m_DeviceInfoList)
//    {
//        [m_DeviceInfoList removeAllObjects];
//        [m_DeviceInfoList release];
//    }
//    if (nil != m_DeviceInfoListGuard)
//    {
//        [m_DeviceInfoListGuard release];
//    }
//
//    if (nil != m_DevListDelegates)
//    {
//        [m_DevListDelegates removeAllObjects];
//        [m_DevListDelegates release];
//    }
//
//    if (nil != m_ReadEventListDelegates)
//    {
//        [m_ReadEventListDelegates removeAllObjects];
//        [m_ReadEventListDelegates release];
//    }
//
//    if (nil != m_InventoryData)
//    {
//        [m_InventoryData release];
//    }
//
//    if (nil != m_ActiveReader)
//    {
//        [m_ActiveReader release];
//    }
//
//    if (nil != m_TriggerEventDelegates)
//    {
//        [m_TriggerEventDelegates removeAllObjects];
//        [m_TriggerEventDelegates release];
//    }
//
//    if (nil != m_BatteryEventDelegates)
//    {
//        [m_BatteryEventDelegates removeAllObjects];
//        [m_BatteryEventDelegates release];
//    }
//
//    if (nil != multiTagEventDelegates)
//    {
//        [multiTagEventDelegates removeAllObjects];
//        [multiTagEventDelegates release];
//    }
//    if (nil != m_BatteryInfo)
//    {
//        [m_BatteryInfo release];
//    }
//
//    if (nil != m_BatteryStatusStr)
//    {
//        [m_BatteryStatusStr release];
//    }
//
//    if (nil != m_BatteryInfoGuard)
//    {
//        [m_BatteryInfoGuard release];
//    }
//
//    if (nil != m_RadioOperationEngine)
//    {
//        [m_RadioOperationEngine release];
//    }
    
//    [super dealloc];
  

}
// JS Event listener
- (NSArray<NSString *> *)supportedEvents {
    return @[@"onReceiveTag", @"onSessionConnect", @"onSessionDisconnect"];
}

// Will be called when this module's first listener is added.
-(void)startObserving {
//    hasListeners = YES;
  NSLog(@"Listener event start");

}

// Will be called when this module's last listener is removed, or on dealloc.
-(void)stopObserving {
//    hasListeners = NO;
  NSLog(@"Listener event stop");
    // Remove upstream listeners, stop unnecessary background tasks
}




RCT_EXPORT_METHOD(initializeReaderSdk) {
  [self initializeRfidSdkWithAppSettings];
}

// Get The Available Reader Devices
RCT_EXPORT_METHOD(getAvailableDevices :(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject)
{
 NSMutableDictionary * readerDevices = [self getAvialableReaderList];

//  NSLog(@"Reader devices count is %lu",count);
  if ([readerDevices count] != 0) {
    NSDictionary *availableReaders = [NSDictionary dictionaryWithDictionary:readerDevices];
    rfidReaderDevices = readerDevices;
    resolve(availableReaders);

  } else {
    reject(@"No Devices", @"No Reader Devices Available", nil);

  }
}

//Connect the device
RCT_EXPORT_METHOD(connectRFIDReader :(NSString *)readerName) {
  
  int readerId = [[rfidReaderDevices valueForKey: readerName] intValue];

  [self connect:readerId];

}

//Disconnect the device
RCT_EXPORT_METHOD(disconnectRFIDReader : (RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject) {

//  int readerId = [[rfidReaderDevices valueForKey: readerName] intValue];
  NSString *disconnectStatus = [self disconnect];
  if ([disconnectStatus isEqualToString : @"Disconnected"]) {
    resolve(@"Disconnected");
  } else {
    resolve(@"Disconnect failed");
  }

}

//Start Inventory operation to perform the tag reading operation
RCT_EXPORT_METHOD(readTagEvents: (NSString *)event resolver:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject) {

  NSString *operationStatus;
  if ([event isEqualToString: @"Listen"]) {
    operationStatus = [self startInventory];
    if ([operationStatus isEqualToString: SUCCESS]) {
      resolve(SUCCESS);
    } else {
      reject(OPERATION_FAILED, @"Read tag listen event failed", nil);
    }

  } else {
    operationStatus = [self stopInventory];
    if ([operationStatus isEqualToString: SUCCESS]) {
      resolve(SUCCESS);
    } else {
      reject(OPERATION_FAILED, @"Read tag unlisten event failed", nil);
    }
  }
}

RCT_EXPORT_METHOD(killTag {
  [self deleteTag];
})

//RCT_EXPORT_METHOD(triggerEvent) {
//  [self checkEvent];
//}




- (void)initializeRfidSdkWithAppSettings {
  
  m_RfidSdkApi = [srfidSdkFactory createRfidSdkApiInstance];
  [m_RfidSdkApi srfidSetDelegate:self];
  
  NSLog(@"Symbol RFID SDK version: %@", [m_RfidSdkApi srfidGetSdkVersion]);
  
  NSUserDefaults *settings = [NSUserDefaults standardUserDefaults];
  
  /*
   NSUserDefaults returns 0 for number if the key doesn't exist
   Check that 0 is not a valid value for the parameter
   
   */
  
  /* TBD: nrv364: load/save actual app settings */
  
  int op_mode = (int)[settings integerForKey:SETTING_OPMODE];
  if (op_mode == 0)
  {
      /* no value => setup default values */
      op_mode = SRFID_OPMODE_MFI;
      [settings setInteger:op_mode forKey:SETTING_OPMODE];
  }
  
  
//  BOOL device_detection = [[self appConfiguration] getConfigConnectionAutoDetection];
  
  int notifications_mask = SRFID_EVENT_READER_APPEARANCE |
  SRFID_EVENT_READER_DISAPPEARANCE |
  SRFID_EVENT_SESSION_ESTABLISHMENT |
  SRFID_EVENT_SESSION_TERMINATION;
  
//  BOOL reconnection = [[self appConfiguration] getConfigConnectionAutoReconnection];
  
  /*
   TBD:
   it doesn't matter in which order enable scanner detection and set op mode:
   - when scanner detection becomes enabled, corresponding discover
   procedure is performed;
   - when opmode becomes enabled, if scanner detection is already enabled,
   corresponding discover procedure is performed (moreover, when some
   opmode becomes disabled, all incompatible scanners are removed from
   available/active lists independently on detection option status)
   Update SRS?
   Because enabling of op mode as well as enabling of detection options
   immidiately results in discover procedure, the app SHALL be already suscribed for
   corresponding notifications.
   */
  [m_RfidSdkApi srfidSetOperationalMode:op_mode];
  [m_RfidSdkApi srfidSubsribeForEvents:notifications_mask];
  /* subscribe for tag data and operation status related events */
   
//  [m_RfidSdkApi srfidSubsribeForEvents:(SRFID_EVENT_MASK_STATUS_OPERENDSUMMARY)];
//  [m_RfidSdkApi srfidSubsribeForEvents:(SRFID_EVENT_MASK_TEMPERATURE | SRFID_EVENT_MASK_POWER | SRFID_EVENT_MASK_DATABASE)];
//  [m_RfidSdkApi srfidUnsubsribeForEvents:(SRFID_EVENT_MASK_RADIOERROR | SRFID_EVENT_MASK_POWER | SRFID_EVENT_MASK_TEMPERATURE)];
//  [m_RfidSdkApi srfidSubsribeForEvents:(SRFID_EVENT_MASK_PROXIMITY)];
//  [m_RfidSdkApi srfidSubsribeForEvents:(SRFID_EVENT_MASK_TRIGGER)];
//  [m_RfidSdkApi srfidSubsribeForEvents:(SRFID_EVENT_MASK_BATTERY)];
//  [m_RfidSdkApi srfidSubsribeForEvents:(SRFID_EVENT_MASK_MULTI_PROXIMITY)];
  [m_RfidSdkApi srfidEnableAvailableReadersDetection:YES];
//  [m_RfidSdkApi srfidEnableAutomaticSessionReestablishment:YES];
  RCTLogInfo(@"Initialized the SDK");
//  [self getAvialableReaderList];
}

-(NSMutableDictionary *)getAvialableReaderList{
  RCTLogInfo(@"Getting Available RFID Readers");
  NSMutableArray *readers = [[NSMutableArray alloc] init];
  NSMutableDictionary *readersInfo = [[NSMutableDictionary alloc]init];
    /* allocate an array for storage of list of available RFID readers */
    NSMutableArray *available_readers = [[NSMutableArray alloc] init];

    /* allocate an array for storage of list of active RFID readers */
    NSMutableArray *active_readers = [[NSMutableArray alloc] init];

    /* retrieve a list of available readers */
    [m_RfidSdkApi srfidGetAvailableReadersList:&available_readers];

    /* retrieve a list of active readers */
    [m_RfidSdkApi srfidGetActiveReadersList:&active_readers];


    [readers addObjectsFromArray:active_readers];
    [readers addObjectsFromArray:available_readers];
    
  if ([readers count] != 0) {
    NSLog(@"Readers are available");
    
    for (srfidReaderInfo *info in readers) {
        /* print the information about RFID reader represented by srfidReaderInfo object */
        NSLog(@"RFID reader is %@: ID = %d name = %@\n", (([info isActive] == YES) ? @"active" : @"available"), [info getReaderID], [info getReaderName]);
//        lable_reader_list.text = [info getReaderName];
//        readerId = [info getReaderID];
      NSNumber * readerId = [NSNumber numberWithInt:[info getReaderID]];
      [readersInfo setValue: [readerId stringValue] forKey:[info getReaderName] ];
//      [readersInfo setValue: [info getReaderName] forKey:@"readerName" ];
      
    }
  } else {
    NSLog(@"Readers are not available");

  }
  return readersInfo;
    
}

// Connect the reader
- (void)connect:(int)reader_id
{
    if (m_RfidSdkApi != nil)
    {
        SRFID_RESULT conn_result = [m_RfidSdkApi srfidEstablishCommunicationSession:reader_id];
       
        if (SRFID_RESULT_SUCCESS == conn_result)
        {
          NSLog(@"Communication session established");
          _connectedReaderId = reader_id;
        } else {
          NSLog(@"Communication session establish error %d", conn_result);
          [self sendEventWithName: @"onSessionConnect" body: @""];
        }
      
    }
}

// This method invokes automatically when the connection established successfully
- (void)srfidEventCommunicationSessionEstablished:(srfidReaderInfo *)activeReader {
    NSLog(@"Reader Connected ");
  NSLog(@"After connection RFID reader is %@: ID = %d name = %@\n", (([activeReader  isActive] == YES) ? @"active" : @"available"), [activeReader  getReaderID], [activeReader  getReaderName]);
  SRFID_RESULT conn_result = [m_RfidSdkApi srfidEstablishAsciiConnection:_connectedReaderId aPassword:@"admin"];
  if (SRFID_RESULT_SUCCESS == conn_result) {
    // Sent event after connection successfull
//    [self sendEventWithName: @"onSessionConnect" body: [activeReader  getReaderName]];
    connectedReaderInfo = activeReader;
    NSLog(@"ASCII connection connected");
    [self setAntennaAndSingulationConfig];
//    [self setAntennaAndSingulationConfig];
//    return @"Connected";
    
  } else {
    [self sendEventWithName: @"onSessionConnect" body: @""];
    NSLog(@"ASCII connection error %d", conn_result);
  }
}

// Disconnect the reader
- (NSString *)disconnect
{
    if (_connectedReaderId != 0)
    {
      SRFID_RESULT disconn_result = [m_RfidSdkApi srfidTerminateCommunicationSession:_connectedReaderId];
      
      if (SRFID_RESULT_SUCCESS == disconn_result)
      {
        _connectedReaderId = 0;
        return @"Disconnected";

      }
    }
  return @"Disconnect failed";
}

-(void)setAntennaAndSingulationConfig {
  NSLog(@"Reader name in antenna method - %@", [connectedReaderInfo getReaderName]);
/* allocate object for storage of antenna settings */
//   srfidAntennaConfiguration *antenna_cfg = [[srfidAntennaConfiguration alloc] init];
/* an object for storage of error response received from RFID reader */
   NSString *error_response = nil;
/* RF mode index to be set */
  int link_profile_idx = 0;
/* tari to be set */
  int tari = 0;
/* 20.0 dbm power level to be set */
  int power = 300;
  
  /* allocate object for storage of link profiles information */
    NSMutableArray *profiles = [[NSMutableArray alloc] init];
  SRFID_RESULT result = SRFID_RESULT_FAILURE;
  /* retrieve supported link profiles */
  for (int i = 0; i< 2; i++) {
    result  = [m_RfidSdkApi srfidGetSupportedLinkProfiles:_connectedReaderId aLinkProfilesList:&profiles aStatusMessage:&error_response];
    if ((result != SRFID_RESULT_RESPONSE_TIMEOUT) && (result != SRFID_RESULT_FAILURE)) {
        break;
    }
  }
    
    if (SRFID_RESULT_SUCCESS == result) {
  if (0 < [profiles count]) {
     srfidLinkProfile *profile = (srfidLinkProfile*)[profiles lastObject];
       link_profile_idx = [profile getRFModeIndex];
     tari = [profile getMaxTari];
    }
   }

  /* allocate object for storage of capabilities information */
    srfidReaderCapabilitiesInfo *capabilities = [[srfidReaderCapabilitiesInfo alloc] init];

  /* retrieve capabilities information */
  for (int i = 0; i < 2; i++) {
    result = [m_RfidSdkApi srfidGetReaderCapabilitiesInfo:_connectedReaderId aReaderCapabilitiesInfo:&capabilities aStatusMessage:&error_response];
    if ((result != SRFID_RESULT_RESPONSE_TIMEOUT) && (result != SRFID_RESULT_FAILURE)) {
        break;
    }
    
  }
    if (SRFID_RESULT_SUCCESS == result) {
     power = [capabilities getMaxPower];
   }
  /* prepare an object with desired antenna parameters */
  srfidAntennaConfiguration *antenna_cfg = [[srfidAntennaConfiguration alloc] init];
    [antenna_cfg setLinkProfileIdx:0];
    [antenna_cfg setPower: 100];
     [antenna_cfg setTari:0];
    [antenna_cfg setDoSelect:NO];
     error_response = nil;
  
    /* set antenna configuration */
  for (int i = 0; i< 2; i++) {
    result = [m_RfidSdkApi srfidSetAntennaConfiguration:_connectedReaderId aAntennaConfiguration:antenna_cfg aStatusMessage:&error_response];
    if ((result != SRFID_RESULT_RESPONSE_TIMEOUT) && (result != SRFID_RESULT_FAILURE)) {
        break;
    }
  }
    if (SRFID_RESULT_SUCCESS == result) {
   /* antenna configuration applied successfully */
       NSLog(@"Antenna configuration has been set, going forward to singulation config\n");
      
      NSString *singulation_config_status = [self setSingulationConfig];
      
      if ([singulation_config_status isEqualToString: @"Success"]) {
//        [self getSetRegulatoryConfig];
//        [self setTagReportConfig];
        [self sendEventWithName: @"onSessionConnect" body: [connectedReaderInfo  getReaderName]];
      } else {
        [self sendEventWithName: @"onSessionConnect" body: @""];
        NSLog(@"Singulation config failed");
      }
    }
     else {
       [self sendEventWithName: @"onSessionConnect" body: @""];
//       if (SRFID_RESULT_RESPONSE_ERROR == result) {
//       NSLog(@"Error response from RFID reader: %@\n", error_response);
//     }
//       else if (SRFID_RESULT_RESPONSE_TIMEOUT == result) {
//       NSLog(@"Timeout occurs during communication with RFID reader\n");
//     }
//       else if (SRFID_RESULT_READER_NOT_AVAILABLE == result) {
//       NSLog(@"RFID reader with id = %d is not available\n", _connectedReaderId);
//     }
      NSLog(@"Antenna Config Failed\n");
    }
//  return @"Failed";

}

-(NSString *)setSingulationConfig {
  // Perform singulation configuration once successfull done the antenna config
  srfidSingulationConfig *singulation_cfg = [[srfidSingulationConfig alloc] init];
    /* an object for storage of error response received from RFID reader */
    NSString *error_response = nil;
  SRFID_RESULT result = SRFID_RESULT_FAILURE;
    /* retrieve singulation configuration */
  for (int i = 0; i < 2; i++) {
    result = [m_RfidSdkApi srfidGetSingulationConfiguration:_connectedReaderId
    aSingulationConfig:&singulation_cfg   aStatusMessage:&error_response];
    if ((result != SRFID_RESULT_RESPONSE_TIMEOUT) && (result != SRFID_RESULT_FAILURE)) {
        break;
    }
  }
   
    if (SRFID_RESULT_SUCCESS == result) {
         /* singulation configuration received */
         NSLog(@"Tag population: %d\n", [singulation_cfg getTagPopulation]);
      SRFID_SLFLAG slflag = [singulation_cfg getSLFlag];
           switch (slflag) {
              case SRFID_SLFLAG_ASSERTED:
                  NSLog(@"SL flag: ASSERTED\n");
                  break;
           case SRFID_SLFLAG_DEASSERTED:
              NSLog(@"SL flag: DEASSERTED\n");
              break;
           case SRFID_SLFLAG_ALL:
              NSLog(@"SL flag: ALL\n");
              break;
      }
           SRFID_SESSION session = [singulation_cfg getSession];
           switch (session) {
              case SRFID_SESSION_S1:
                  NSLog(@"Session: S1\n");
                  break;
              case SRFID_SESSION_S2:
                  NSLog(@"Session: S2\n");
                  break;
              case SRFID_SESSION_S3:
                  NSLog(@"Session: S3\n");
                  break;
              case SRFID_SESSION_S0:
                  NSLog(@"Session: S0\n");
                  break;
           }
           SRFID_INVENTORYSTATE state = [singulation_cfg getInventoryState];
           switch (state) {
              case SRFID_INVENTORYSTATE_A:
                  NSLog(@"Inventory State: State A\n");
                  break;
              case SRFID_INVENTORYSTATE_B:
                  NSLog(@"Inventory State: State B\n");
                  break;
                  case SRFID_INVENTORYSTATE_AB_FLIP:
                  NSLog(@"Inventory State: AB flip\n");
                  break;
           }
           /* change the received singulation configuration */
      
           [singulation_cfg setTagPopulation:30];
           [singulation_cfg setSession:SRFID_SESSION_S1];
           [singulation_cfg setSlFlag:SRFID_SLFLAG_ALL];
           [singulation_cfg setInventoryState:SRFID_INVENTORYSTATE_A];
            
      configured_singulation = singulation_cfg;
//      inventoryState = state;
           error_response = nil;
           /* set updated singulation configuration */
      for (int i = 0; i< 2; i++) {
        result = [m_RfidSdkApi srfidSetSingulationConfiguration:_connectedReaderId
   aSingulationConfig:singulation_cfg aStatusMessage:&error_response];
        if ((result != SRFID_RESULT_RESPONSE_TIMEOUT) && (result != SRFID_RESULT_FAILURE)) {
            break;
        }
      }
          
      if (SRFID_RESULT_SUCCESS == result) {
                 /* singulation configuration applied successfully */
          NSLog(@"Singulation configuration has been set\n");

//        configured_singulation = singulation_cfg;
//          SRFID_RESULT deleteTagResult = [m_RfidSdkApi srfidPurgeTags:_connectedReaderId aStatusMessage:NULL];
//        if (deleteTagResult == SRFID_RESULT_SUCCESS) {
               NSString *regulatoryStatus =   [self getSetRegulatoryConfig];
        if ([regulatoryStatus isEqualToString: SUCCESS]) {

          return SUCCESS;
        }
//
//        }


//        [self triggerConfig];
//        return SUCCESS;
             }
             else if (SRFID_RESULT_RESPONSE_ERROR == result) {
                 NSLog(@"Error response from RFID reader: %@\n", error_response);
             }
             else if (SRFID_RESULT_RESPONSE_TIMEOUT == result) {
                 NSLog(@"Timeout occurs during communication with RFID reader\n");
             }
             else if (SRFID_RESULT_READER_NOT_AVAILABLE == result) {
                 NSLog(@"RFID reader with id = %d is not available\n", _connectedReaderId);
             }
             else {
                 NSLog(@"Request failed\n");
     } }
        else if (SRFID_RESULT_RESPONSE_ERROR == result) {
             NSLog(@"Error response from RFID reader: %@\n", error_response);
        }
        else if (SRFID_RESULT_RESPONSE_TIMEOUT == result) {
             NSLog(@"Timeout occurs during communication with RFID reader\n");
        }
        else if (SRFID_RESULT_READER_NOT_AVAILABLE == result) {
             NSLog(@"RFID reader with id = %d is not available\n", _connectedReaderId);
     } else {
             NSLog(@"Request failed\n");
        }
    
  return FAILED;
}

-(NSString *)getSetRegulatoryConfig{

/* allocate object for storage of regulatory settings */
  srfidRegulatoryConfig *regulatory_cfg = [[srfidRegulatoryConfig alloc] init];

/* an object for storage of error response received from RFID reader */
  NSString *error_response = nil;
  SRFID_RESULT result = SRFID_RESULT_FAILURE;

/* retrieve regulatory parameters */
  for (int i = 0; i< 2; i++) {
    result = [m_RfidSdkApi srfidGetRegulatoryConfig:_connectedReaderId aRegulatoryConfig:&regulatory_cfg aStatusMessage:&error_response];
    if ((result != SRFID_RESULT_RESPONSE_TIMEOUT) && (result != SRFID_RESULT_FAILURE)) {
        break;
    }
  }
 
  if (SRFID_RESULT_SUCCESS == result) {
/* regulatory configuration received */
  if (NSOrderedSame == [[regulatory_cfg getRegionCode] caseInsensitiveCompare:@"NA"]) {
    NSLog(@"Regulatory: region is NOT set\n");
    }
    else {
        NSLog(@"Region code: %@\n", [regulatory_cfg getRegionCode]);
      SRFID_HOPPINGCONFIG hopping_cfg = [regulatory_cfg getHoppingConfig];
      NSLog(@"Hopping is %@\n", ((SRFID_HOPPINGCONFIG_DISABLED == hopping_cfg) ? @"off" : @"on"));
    NSArray *channels = [regulatory_cfg getEnabledChannelsList];
    for (NSString *str in channels) {
    NSLog(@"Enabled channel: %@\n", str);
    }
  }
}
  else {
      NSLog(@"Failed to receive regulatory parameters\n");
    return FAILED;
   }
/* code of region to be set as current one */
  NSString *region_code = @"IND";
/* an array of enabled channels to be set */
  NSMutableArray *enabled_channels = [[NSMutableArray alloc] init];
/* a hopping to be set  */
  SRFID_HOPPINGCONFIG hopping_on = SRFID_HOPPINGCONFIG_DISABLED;

/* allocate object for storage of region information */
  NSMutableArray *regions = [[NSMutableArray alloc] init];

/* retrieve supported regions */
  for (int i = 0; i<2; i++) {
    result = [m_RfidSdkApi srfidGetSupportedRegions:_connectedReaderId aSupportedRegions: &regions aStatusMessage:&error_response];
    if ((result != SRFID_RESULT_RESPONSE_TIMEOUT) && (result != SRFID_RESULT_FAILURE)) {
        break;
    }
  }
 

  if (SRFID_RESULT_SUCCESS == result) {
/* supported regions information received */
/* select the last supported regions to be set as current one */
    region_code = [NSString stringWithFormat:@"%@", [(srfidRegionInfo*)[regions lastObject] getRegionCode]];
}

  /* allocate object for storage of supported channels information */
  NSMutableArray *supported_channels = [[NSMutableArray alloc] init];
  BOOL hopping_configurable = NO;

/* retrieve detailed information about region specified by region code */
  for (int i = 0; i < 2; i++) {
    result = [m_RfidSdkApi srfidGetRegionInfo:_connectedReaderId aRegionCode:region_code aSupportedChannels:&supported_channels aHoppingConfigurable:&hopping_configurable aStatusMessage:&error_response];
    if ((result != SRFID_RESULT_RESPONSE_TIMEOUT) && (result != SRFID_RESULT_FAILURE)) {
        break;
    }
  }
  

  if (SRFID_RESULT_SUCCESS == result) {
/* region information received */
  if (YES == hopping_configurable) {
/* region supports hopping */
/* enable first and last channels from the set of supported channels */
  [enabled_channels addObject:[supported_channels firstObject]];
  [enabled_channels addObject:[supported_channels lastObject]];
/* enable hopping */
  hopping_on = SRFID_HOPPINGCONFIG_ENABLED;
}
  else {
/* region does not support hopping */
/* request to not configure hopping */
  hopping_on = SRFID_HOPPINGCONFIG_DEFAULT;
     }
  }
  error_response = nil;
  /* configure regulatory parameters to be set */
  regulatory_cfg = [[srfidRegulatoryConfig alloc] init];
  [regulatory_cfg setRegionCode:region_code];
  [regulatory_cfg setEnabledChannelsList:enabled_channels];
  [regulatory_cfg setHoppingConfig:hopping_on];

/* set regulatory parameters */
  for (int i = 0; i < 2; i++) {
    result = [m_RfidSdkApi srfidSetRegulatoryConfig:_connectedReaderId aRegulatoryConfig:regulatory_cfg aStatusMessage:&error_response];
    if ((result != SRFID_RESULT_RESPONSE_TIMEOUT) && (result != SRFID_RESULT_FAILURE)) {
        break;
    }
  }

  if (SRFID_RESULT_SUCCESS == result) {
/* regulatory configuration applied */
  NSLog(@"Tag report configuration has been set regulatory\n");
//    [self uniqueTagReport];
    return SUCCESS;
//    [self startInventory];
 }
  else if (SRFID_RESULT_RESPONSE_ERROR == result) {
   NSLog(@"Error response from RFID reader: %@\n", error_response);
 }
  else {
    NSLog(@"Failed to set regulatory parameters\n");
 }
  return FAILED;
}



-(void)getTagReportConfig {
/* allocate object for storage of tag report settings */
  srfidTagReportConfig *report_cfg = [[srfidTagReportConfig alloc] init];
/* an object for storage of error response received from RFID reader */
  NSString *error_response = nil;
/* retrieve tag report parameters */
  SRFID_RESULT result = [m_RfidSdkApi srfidGetTagReportConfiguration:_connectedReaderId aTagReportConfig:&report_cfg aStatusMessage:&error_response];
  if (SRFID_RESULT_SUCCESS == result) {
/* tag report configuration received */
  NSLog(@"PC field: %@\n", ((NO == [report_cfg getIncPC]) ? @"off" : @"on"));
  NSLog(@"Phase field: %@\n", ((NO == [report_cfg getIncPhase]) ? @"off" : @"on"));
  NSLog(@"Channel index field: %@\n", ((NO == [report_cfg getIncChannelIdx]) ? @"off" : @"on"));
  NSLog(@"RSSI field: %@\n", ((NO == [report_cfg getIncRSSI]) ? @"off" : @"on"));
  NSLog(@"Tag seen count field: %@\n", ((NO == [report_cfg getIncTagSeenCount]) ? @"off" : @"on"));
  NSLog(@"First seen time field: %@\n", ((NO == [report_cfg getIncFirstSeenTime]) ? @"off" : @"on"));
  NSLog(@"Last seen time field: %@\n", ((NO == [report_cfg getIncLastSeenTime]) ? @"off" : @"on"));
}
  else {
  NSLog(@"Failed to receive tag report parameters\n");
}
  }
  -(void)setTagReportConfig {
/* allocate object for storage of tag report settings */
  srfidTagReportConfig *report_cfg = [[srfidTagReportConfig alloc] init];
/* an object for storage of error response received from RFID reader */
  NSString *error_response = nil;
/* configure tag report parameters to include only RSSI field */
  [report_cfg setIncRSSI:YES];
  [report_cfg setIncPC:NO];
  [report_cfg setIncPhase:NO];
  [report_cfg setIncChannelIdx:NO];
  [report_cfg setIncTagSeenCount:NO];
  [report_cfg setIncFirstSeenTime:NO];
  [report_cfg setIncLastSeenTime:NO];

/* set tag report parameters */
  SRFID_RESULT result = [m_RfidSdkApi srfidSetTagReportConfiguration:_connectedReaderId aTagReportConfig:report_cfg aStatusMessage:&error_response];
  if (SRFID_RESULT_SUCCESS == result) {
/* tag report configuration applied */
  NSLog(@"Tag report configuration has been set\n");
//    srfidUniqueTagsReport* setUniqueTag = [[srfidUniqueTagsReport alloc]init];
//      [setUniqueTag setUniqueTagsReportEnabled:true];
//      NSString *statusMessage = nil;
//      SRFID_RESULT result = [m_RfidSdkApi srfidSetUniqueTagReportConfiguration:_connectedReaderId
//      aUtrConfiguration:setUniqueTag aStatusMessage:&statusMessage];
//      if (SRFID_RESULT_SUCCESS == result) {
//      NSLog(@"Set Unique Tag Reporting succeeded\n");
//      }
//      else {
//      NSLog(@"Request failed\n");
//      }
//    [self getSetRegulatoryConfig];
}
  else {
  NSLog(@"Failed to set tag report parameters\n");
  }
}

-(void) uniqueTagReport {
  srfidUniqueTagsReport *setUniqueTag = [[srfidUniqueTagsReport alloc]init];
  [setUniqueTag setUniqueTagsReportEnabled: YES];
  NSString *statusMessage = nil;
  SRFID_RESULT uniqueTagReport = [m_RfidSdkApi srfidSetUniqueTagReportConfiguration:_connectedReaderId
  aUtrConfiguration:setUniqueTag aStatusMessage:&statusMessage];
  
//  SRFID_RESULT purge = [m_RfidSdkApi srfidPurgeTags:_connectedReaderId aStatusMessage: &statusMessage];
//  NSLog(@"status message %d", purge);

  if (SRFID_RESULT_SUCCESS == uniqueTagReport) {
  NSLog(@"Set Unique Tag Reporting succeeded\n");

  }
  else {
  NSLog(@"Unique tag Request failed %@\n", statusMessage);
  }

}

-(void) getUniqueReport {
  srfidUniqueTagsReport* __autoreleasing getUniqueTag = [[srfidUniqueTagsReport alloc]init];
    NSString *statusMessage = nil;
    SRFID_RESULT result = [m_RfidSdkApi srfidGetUniqueTagReportConfiguration:_connectedReaderId
    aUtrConfiguration:&getUniqueTag aStatusMessage:&statusMessage];
  NSLog(@"unique tag, %d", [getUniqueTag getUniqueTagsReportEnabled]);
  
}

- (int) resetSingulationConfig {
  NSString *error_response = nil;
  SRFID_INVENTORYSTATE state = [configured_singulation getInventoryState];
  [configured_singulation setInventoryState: state == SRFID_INVENTORYSTATE_A ? SRFID_INVENTORYSTATE_B : SRFID_INVENTORYSTATE_A ];
  SRFID_RESULT  result = [m_RfidSdkApi srfidSetSingulationConfiguration:_connectedReaderId
     aSingulationConfig: configured_singulation aStatusMessage:&error_response];
//    SRFID_RESULT result = [m_RfidSdkApi srfidPurgeTags:_connectedReaderId aStatusMessage: &error_response];
  if (SRFID_RESULT_SUCCESS == result) {
    NSLog(@"Singulation reset successfull");
  } else {
    NSLog(@"Reset Singulation failed %@", error_response);
  }
  return result;
  
}



// start inventory for perform the read tag events
- (NSString *) startInventory {
  srfidUniqueTagsReport *setUniqueTag = [[srfidUniqueTagsReport alloc]init];
  [setUniqueTag setUniqueTagsReportEnabled: true];
  SRFID_RESULT  srfid_result = SRFID_RESULT_SUCCESS;
  NSString *responseMessage = nil;
  for(int i = 0; i < 2; i++)
  {
      srfid_result = [m_RfidSdkApi srfidSetUniqueTagReportConfiguration: _connectedReaderId aUtrConfiguration: setUniqueTag aStatusMessage: &responseMessage];
      
      if ((srfid_result != SRFID_RESULT_RESPONSE_TIMEOUT) && (srfid_result != SRFID_RESULT_FAILURE)) {
          break;
      }
      // purge tags on settings change
//      [m_RfidSdkApi srfidPurgeTags: _connectedReaderId aStatusMessage:NULL];
  }
  if (srfid_result == SRFID_RESULT_SUCCESS) {
    NSLog(@"Unique tag report success");
  } else {
    NSLog(@"unique error response, %@", responseMessage);
  }
//  [self resetSingulationConfig];

  /* subscribe for tag data related events */
//      [m_RfidSdkApi srfidSubsribeForEvents:SRFID_EVENT_MASK_READ];
//      /* subscribe for operation start/stop related events */
//      [m_RfidSdkApi srfidSubsribeForEvents:SRFID_EVENT_MASK_STATUS];
      [m_RfidSdkApi srfidSubsribeForEvents:(SRFID_EVENT_MASK_READ | SRFID_EVENT_MASK_STATUS)];
  /* subscribe for battery and hand-held trigger related events */
      [m_RfidSdkApi srfidSubsribeForEvents:(SRFID_EVENT_MASK_BATTERY |SRFID_EVENT_MASK_TRIGGER)];
//
//      /* identifier of one of active RFID readers is supposed to be stored in m_ReaderId variable */
//
//      /* allocate object for start trigger settings */
      srfidStartTriggerConfig *start_trigger_cfg = [[srfidStartTriggerConfig alloc] init];

      /* allocate object for stop trigger settings */
      srfidStopTriggerConfig *stop_trigger_cfg = [[srfidStopTriggerConfig alloc] init];
  
      report_cfg = [[srfidReportConfig alloc] init];

      /* allocate object for access parameters of inventory operation */
     access_cfg = [[srfidAccessConfig alloc] init];
  SRFID_RESULT result = SRFID_RESULT_FAILURE;
  

      /* allocate object for report parameters of inventory operation */
  

      /* an object for storage of error response received from RFID reader */
      NSString *error_response = nil;

          /* configure start triggers parameters to start on physical trigger press */
          [start_trigger_cfg setStartOnHandheldTrigger:NO];
//          [start_trigger_cfg setTriggerType:SRFID_TRIGGERTYPE_PRESS];
          [start_trigger_cfg setStartDelay:0];
          [start_trigger_cfg setRepeatMonitoring:NO];
  
//
//          /* configure stop triggers parameters to stop on physical trigger release or on 25 sec timeout  */
//          [stop_trigger_cfg setStopOnHandheldTrigger:NO];
////          [stop_trigger_cfg setTriggerType:SRFID_TRIGGERTYPE_RELEASE];
//          [stop_trigger_cfg setStopOnTimeout:NO];
//          [stop_trigger_cfg setStopOnTagCount:NO];
////          [stop_trigger_cfg setStopTimout:(25*1000)];
//
//          [stop_trigger_cfg setStopOnInventoryCount:NO];
//          [stop_trigger_cfg setStopOnAccessCount:NO];
//
  [stop_trigger_cfg setStopOnHandheldTrigger:NO];
  [stop_trigger_cfg setStopOnTagCount:NO];
  [stop_trigger_cfg setStopOnTimeout:NO];
  [stop_trigger_cfg setStopOnInventoryCount:NO];
  [stop_trigger_cfg setStopTagCount:0];
  [stop_trigger_cfg setStopTimout:0];
  [stop_trigger_cfg setStopInventoryCount:0];
//
//          /* set start trigger parameters */
  for (int i = 0; i< 2; i++) {
    result = [m_RfidSdkApi srfidSetStartTriggerConfiguration:_connectedReaderId aStartTriggeConfig:start_trigger_cfg aStatusMessage:&error_response];
if ((srfid_result != SRFID_RESULT_RESPONSE_TIMEOUT) && (srfid_result != SRFID_RESULT_FAILURE)) {
 break;
}
    
  }
          if (SRFID_RESULT_SUCCESS == result) {
              /* start trigger configuration applied */
              NSLog(@"Start trigger configuration has been set\n");
          }
          else {
              NSLog(@"Failed to set start trigger parameters\n");
            return FAILED;
          }
          /* set stop trigger parameters */
  for (int i = 0; i< 2; i++) {
    result = [m_RfidSdkApi srfidSetStopTriggerConfiguration:_connectedReaderId aStopTriggeConfig:stop_trigger_cfg aStatusMessage:&error_response];
if ((srfid_result != SRFID_RESULT_RESPONSE_TIMEOUT) && (srfid_result != SRFID_RESULT_FAILURE)) {
break;
}
    
  }
          if (SRFID_RESULT_SUCCESS == result) {
              /* stop trigger configuration applied */
              NSLog(@"Stop trigger configuration has been set\n");
          }
          else {
              NSLog(@"Failed to set stop trigger parameters\n");
            return FAILED;
          }
  
 
          
          //Reset Singulation Config
//          result = [self resetSingulationConfig: 2];
//  if (SRFID_RESULT_SUCCESS == result) {
//    NSLog(@"Reset Config success");
//  } else {
//    return FAILED;
//  }
          
  [report_cfg setIncPC:NO];
  [report_cfg setIncPhase:NO];
  [report_cfg setIncChannelIndex:YES];
  [report_cfg setIncRSSI:YES];
  [report_cfg setIncTagSeenCount:NO];
  [report_cfg setIncFirstSeenTime:NO];
  [report_cfg setIncLastSeenTime:NO];
      
  /* configure access parameters to perform the operation with 27.0 dbm antenna power level without application of pre-filters */
  [access_cfg setPower:270];
  [access_cfg setDoSelect:NO];
  return SUCCESS;
              
          /* start and stop triggers have been configured */
//          error_response = nil;
//
//          /* configure report parameters to report RSSI and Channel Index fields */
//
//          /* request performing of inventory operation with reading from EPC memory bank */
//  result = [m_RfidSdkApi srfidStartInventory:_connectedReaderId aMemoryBank:SRFID_MEMORYBANK_EPC aReportConfig:report_cfg aAccessConfig:access_cfg aStatusMessage:&error_response];
//
//          if (SRFID_RESULT_SUCCESS == result) {
//              NSLog(@"Inventory start Request succeed\n");
////               request abort of an operation after 1 minute
////              dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(60 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
////                  [self->m_RfidSdkApi srfidStopInventory:1 aStatusMessage:nil];
////              });
//            return SUCCESS;
//          }
//          else if (SRFID_RESULT_RESPONSE_ERROR == result) {
//              NSLog(@"Inventory start Error response from RFID reader: %@\n", error_response);
//          }
//          else {
//              NSLog(@"Inventory startRequest failed\n");
//          }
//
//  return FAILED;
                
  
}

-(void) deleteTag {
  srfidTagData *tagData = [[srfidTagData alloc] init];
  NSString *status = nil;
 SRFID_RESULT result =  [m_RfidSdkApi srfidKillTag: _connectedReaderId aTagID : @"E2801191A5030060EFABE707" aAccessTagData:&tagData aPassword: 00000000 aStatusMessage: &status];
  if (result == SRFID_RESULT_SUCCESS) {
    NSLog(@"Kill tag success");
  } else {
    NSLog(@"kill tag failed");
  }
  
}


// stop inventory for stop reading tags
- (NSString *) stopInventory {
  
  NSString *error_response = nil;
  
  SRFID_RESULT result = [m_RfidSdkApi srfidStopInventory:_connectedReaderId aStatusMessage:&error_response];
  if (SRFID_RESULT_SUCCESS == result) {
      NSLog(@"Inventory stopped\n");
    SRFID_RESULT purge = [m_RfidSdkApi srfidPurgeTags:_connectedReaderId aStatusMessage: NULL];
//    if ()
    
    
//    [self resetSingulationConfig];
//    return SUCCESS;
    // Reset the Singulation session
//    result = [self resetSingulationConfig: 0];
    if (SRFID_RESULT_SUCCESS == result) {
      NSLog(@"Reset config successfull session 0");
//      [m_RfidSdkApi srfidPurgeTags:_connectedReaderId aStatusMessage:NULL];
      return SUCCESS;
      
    } else {
      NSLog(@"Reset config failed 0");
    }
  }
  else if (SRFID_RESULT_RESPONSE_ERROR == result) {
      NSLog(@"Inventory stop Error response from RFID reader: %@\n", error_response);
  }
  else {
      NSLog(@"Inventory stop Inventory stop Request failed\n");
  }
  return FAILED;
  
}



//-(void)getTagReportConfig {
///* allocate object for storage of tag report settings */
//  srfidTagReportConfig *report_cfg = [[srfidTagReportConfig alloc] init];
///* an object for storage of error response received from RFID reader */
//  NSString *error_response = nil;
///* retrieve tag report parameters */
//  SRFID_RESULT result = [_apiInsta srfidGetTagReportConfiguration:_connectedRederID aTagReportConfig:&report_cfg aStatusMessage:&error_response];
//  if (SRFID_RESULT_SUCCESS == result) {
///* tag report configuration received */
//  NSLog(@"PC field: %@\n", ((NO == [report_cfg getIncPC]) ? @"off" : @"on"));
//  NSLog(@"Phase field: %@\n", ((NO == [report_cfg getIncPhase]) ? @"off" : @"on"));
//  NSLog(@"Channel index field: %@\n", ((NO == [report_cfg getIncChannelIdx]) ? @"off" : @"on"));
//  NSLog(@"RSSI field: %@\n", ((NO == [report_cfg getIncRSSI]) ? @"off" : @"on"));
//  NSLog(@"Tag seen count field: %@\n", ((NO == [report_cfg getIncTagSeenCount]) ? @"off" : @"on"));
//  NSLog(@"First seen time field: %@\n", ((NO == [report_cfg getIncFirstSeenTime]) ? @"off" : @"on"));
//  NSLog(@"Last seen time field: %@\n", ((NO == [report_cfg getIncLastSeenTime]) ? @"off" : @"on"));
//}
//  else {
//  NSLog(@"Failed to receive tag report parameters\n");
//}
//  }




//- (void) checkEvent
//{
//  if (hasListeners) {// Only send events if anyone is listening
//    [self sendEventWithName:@"IOSEvent" body:@"tag data"];
//  }
//}

//Events
- (void)srfidEventStatusNotify:(int)readerID aEvent:(SRFID_EVENT_STATUS)event aNotification:(id)notificationData {
    NSLog(@"Radio operation has %@\n", ((SRFID_EVENT_STATUS_OPERATION_START == event) ? @"started" : @"stopped"));
  
}
- (void)srfidEventReadNotify:(int)readerID aTagData:(srfidTagData *)tagData {
    /* print the received tag data */
    NSLog(@"Tag data received from RFID reader with ID = %d\n", readerID);
    NSLog(@"Tag id: %@\n", [tagData getTagId]);
  
   [self sendEventWithName:@"onReceiveTag" body:[tagData getTagId]]; // send the tag ID to JS
  
    SRFID_MEMORYBANK bank = [tagData getMemoryBank];
  
    if (SRFID_MEMORYBANK_NONE != bank) {
        NSString *str_bank = @"";
        switch (bank) {
            case SRFID_MEMORYBANK_EPC:
                str_bank = @"EPC";
                break;
            case SRFID_MEMORYBANK_TID:
                str_bank = @"TID";
                break;
            case SRFID_MEMORYBANK_USER:
                str_bank = @"USER";
                break;

            case SRFID_MEMORYBANK_RESV:
                str_bank = @"RESV";
                break;
            case SRFID_MEMORYBANK_NONE:
                str_bank = @"None";
                break;
            case SRFID_MEMORYBANK_ACCESS:
                str_bank = @"Acess";
                break;
            case SRFID_MEMORYBANK_KILL:
                str_bank = @"Kill";
                break;
            case SRFID_MEMORYBANK_ALL:
                str_bank = @"All";
                break;
        }
        NSLog(@"%@ memory bank data: %@\n", str_bank, [tagData getMemoryBankData]);
    }
}




// Disconnect listener
- (void)srfidEventCommunicationSessionTerminated:(int)readerID {
if (_connectedReaderId != 0) {
  _connectedReaderId = 0;
  [self sendEventWithName: @"onSessionDisconnect" body: @""];
}
  NSLog(@"Reader Disconnected %d", _connectedReaderId);
}

- (void)srfidEventReaderAppeared:(srfidReaderInfo *)availableReader {
  NSLog(@"RFID reader is %@: ID = %d name = %@\n", (([availableReader isActive] == YES) ? @"active" : @"available"), [availableReader getReaderID], [availableReader getReaderName]);
}

- (void)srfidEventReaderDisappeared:(int)readerID {
  NSLog(@"Reader disapperared");
}
- (void)srfidEventTriggerNotify:(int)readerID aTriggerEvent:(SRFID_TRIGGEREVENT)triggerEvent {
  if (SRFID_TRIGGEREVENT_PRESSED == triggerEvent) {
    NSLog(@"Trigger pressed");
   
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
      NSString *error_response = nil;
    SRFID_RESULT  result = [self -> m_RfidSdkApi srfidStartInventory:self -> _connectedReaderId aMemoryBank:SRFID_MEMORYBANK_EPC aReportConfig: self -> report_cfg aAccessConfig: self -> access_cfg aStatusMessage:&error_response];

              if (SRFID_RESULT_SUCCESS == result) {
                  NSLog(@"Inventory start Request succeed\n");
    //               request abort of an operation after 1 minute
    //              dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(60 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    //                  [self->m_RfidSdkApi srfidStopInventory:1 aStatusMessage:nil];
    //              });
              }
              else if (SRFID_RESULT_RESPONSE_ERROR == result) {
                  NSLog(@"Inventory start Error response from RFID reader: %@\n", error_response);
              }
              else {
                  NSLog(@"Inventory startRequest failed %@\n", error_response);
              }
      
     });
  } else {
    NSLog(@"Trigger released");
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
      NSString *error_response = nil;
      
      SRFID_RESULT result = [self -> m_RfidSdkApi srfidStopInventory: self -> _connectedReaderId aStatusMessage:&error_response];
      if (SRFID_RESULT_SUCCESS == result) {
          NSLog(@"Inventory stopped\n");
        [self -> m_RfidSdkApi srfidPurgeTags:self -> _connectedReaderId aStatusMessage: NULL];
    //    if ()
        
        
    //    [self resetSingulationConfig];
    //    return SUCCESS;
        // Reset the Singulation session
    //    result = [self resetSingulationConfig: 0];
        if (SRFID_RESULT_SUCCESS == result) {
          NSLog(@"Reset config successfull session 0");
    //      [m_RfidSdkApi srfidPurgeTags:_connectedReaderId aStatusMessage:NULL];
          
        } else {
          NSLog(@"Reset config failed 0");
        }
      }
      else if (SRFID_RESULT_RESPONSE_ERROR == result) {
          NSLog(@"Inventory stop Error response from RFID reader: %@\n", error_response);
      }
      else {
          NSLog(@"Inventory stop Inventory stop Request failed %@\n", error_response);
      }
      
     });
  }
}


@end
